import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';

export interface DeviceInfo {
  os?: string;
  browser?: string;
  screen?: string;
  cores?: number;
  gpu?: string;
  userAgent?: string;
  timezone?: string;
  language?: string;
  memory?: string;
}

export interface GeoLocation {
  city: string;
  region: string;
  country: string;
  countryCode: string;
  flag: string;
  isp?: string;
  lat?: number;
  lon?: number;
}

export interface LicenseRecord {
  id: string;
  key: string;
  status: 'active' | 'paused' | 'expired' | 'revoked';
  durationDays: number;
  durationType: 'days' | 'months' | 'years' | 'lifetime';
  createdAt: string;
  activatedAt: string | null;
  expiresAt: string | null;
  boundHwid: string | null;
  boundDeviceInfo: DeviceInfo | null;
  boundIp: string | null;
  lastSeenAt: string | null;
  lastLocation?: GeoLocation | null;
  notes: string;
}

export interface AccessLog {
  id: string;
  timestamp: string;
  action: 'activate' | 'verify' | 'app_request' | 'blocked' | 'admin_change' | 'kill_session' | 'ban_device';
  key?: string;
  hwid?: string;
  ip?: string;
  location?: string;
  success: boolean;
  reason: string;
  details?: string;
}

export interface MaintenanceConfig {
  enabled: boolean;
  reason: string;
  updatedAt: string;
}

interface DatabaseSchema {
  adminKey: string;
  jwtSecret: string;
  licenses: LicenseRecord[];
  logs: AccessLog[];
  maintenance: MaintenanceConfig;
  bannedHwids: string[];
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.resolve(DATA_DIR, 'db.json');
const BUNDLE_FILE = path.resolve(process.cwd(), 'server', 'assets', 'zyre-bundle.js');

// ----------------------------------------------------
// GEOLOCATION & ACTIVE TRACKING IN-MEMORY ENGINE
// ----------------------------------------------------

const geoCache = new Map<string, GeoLocation>();

function getFlagEmoji(countryCode: string): string {
  if (!countryCode || countryCode.length !== 2) return '🌐';
  try {
    const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 127397 + char.charCodeAt(0));
    return String.fromCodePoint(...codePoints);
  } catch {
    return '🌐';
  }
}

function resolveLocationFromTimezone(timezone?: string): GeoLocation {
  const tz = timezone || 'UTC';
  const tzLower = tz.toLowerCase();

  let country = 'Global';
  let countryCode = 'GL';
  let city = tz.split('/')[1]?.replace(/_/g, ' ') || 'Unknown City';
  let region = tz.split('/')[0]?.replace(/_/g, ' ') || 'Global';

  if (tzLower.includes('new_york') || tzLower.includes('chicago') || tzLower.includes('los_angeles') || tzLower.includes('denver') || tzLower.includes('phoenix') || tzLower.includes('america/')) {
    country = 'United States';
    countryCode = 'US';
  } else if (tzLower.includes('london') || tzLower.includes('belfast') || tzLower.includes('glasgow')) {
    country = 'United Kingdom';
    countryCode = 'GB';
  } else if (tzLower.includes('paris')) {
    country = 'France';
    countryCode = 'FR';
  } else if (tzLower.includes('berlin') || tzLower.includes('frankfurt')) {
    country = 'Germany';
    countryCode = 'DE';
  } else if (tzLower.includes('toronto') || tzLower.includes('vancouver') || tzLower.includes('montreal')) {
    country = 'Canada';
    countryCode = 'CA';
  } else if (tzLower.includes('sydney') || tzLower.includes('melbourne') || tzLower.includes('brisbane')) {
    country = 'Australia';
    countryCode = 'AU';
  } else if (tzLower.includes('tokyo')) {
    country = 'Japan';
    countryCode = 'JP';
  } else if (tzLower.includes('dubai')) {
    country = 'United Arab Emirates';
    countryCode = 'AE';
  } else if (tzLower.includes('amsterdam')) {
    country = 'Netherlands';
    countryCode = 'NL';
  } else if (tzLower.includes('stockholm')) {
    country = 'Sweden';
    countryCode = 'SE';
  }

  return {
    city,
    region,
    country,
    countryCode,
    flag: getFlagEmoji(countryCode),
    isp: 'Regional ISP'
  };
}

async function resolveLocation(ip: string, timezone?: string): Promise<GeoLocation> {
  const cleanIp = ip.replace(/^.*:/, '').trim();

  // Private/loopback networks
  if (
    !cleanIp ||
    cleanIp === '127.0.0.1' ||
    cleanIp === 'localhost' ||
    cleanIp.startsWith('10.') ||
    cleanIp.startsWith('192.168.') ||
    cleanIp.startsWith('172.16.')
  ) {
    return resolveLocationFromTimezone(timezone);
  }

  if (geoCache.has(cleanIp)) {
    return geoCache.get(cleanIp)!;
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);

    const res = await fetch(`https://ipwho.is/${cleanIp}`, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && data.success) {
        const loc: GeoLocation = {
          city: data.city || 'Unknown City',
          region: data.region || '',
          country: data.country || 'Unknown Country',
          countryCode: data.country_code || '',
          flag: data.flag?.emoji || getFlagEmoji(data.country_code || ''),
          isp: data.connection?.isp || data.connection?.org || 'Broadband ISP',
          lat: data.latitude,
          lon: data.longitude
        };
        geoCache.set(cleanIp, loc);
        return loc;
      }
    }
  } catch {}

  const fallback = resolveLocationFromTimezone(timezone);
  geoCache.set(cleanIp, fallback);
  return fallback;
}

export interface TrackedActiveSession {
  hwid: string;
  key: string;
  ip: string;
  lastSeenAt: string;
  lastSeenTimestamp: number;
  deviceInfo: DeviceInfo;
  location: GeoLocation;
  currentAction: string;
}

// In-memory active devices map
const activeDevices = new Map<string, TrackedActiveSession>();

// Invalidate specific sessions when kicked
const revokedSessionTokens = new Set<string>();

// ----------------------------------------------------
// DATABASE INITIALIZATION & LOGGING
// ----------------------------------------------------

function initDatabase(): DatabaseSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const defaultDb: DatabaseSchema = {
    adminKey: process.env.ADMIN_KEY || 'zyre2026',
    jwtSecret: crypto.randomBytes(32).toString('hex'),
    licenses: [],
    logs: [
      {
        id: 'log_init',
        timestamp: new Date().toISOString(),
        action: 'admin_change',
        success: true,
        reason: 'System database initialized with HWID security & live telemetry engine',
        details: 'Admin portal accessible via /adminzyre'
      }
    ],
    maintenance: {
      enabled: false,
      reason: 'System is under scheduled maintenance. Access temporarily suspended.',
      updatedAt: new Date().toISOString()
    },
    bannedHwids: []
  };

  if (fs.existsSync(DB_FILE)) {
    try {
      const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
      if (data && data.licenses && data.adminKey) {
        if (!data.maintenance) {
          data.maintenance = defaultDb.maintenance;
        }
        if (!Array.isArray(data.bannedHwids)) {
          data.bannedHwids = [];
        }
        return data;
      }
    } catch (e) {
      console.error('Error reading db.json, creating fresh:', e);
    }
  }

  fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb, null, 2), 'utf-8');
  return defaultDb;
}

let db = initDatabase();

function saveDatabase() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to save db.json:', err);
  }
}

function logEvent(
  action: AccessLog['action'],
  success: boolean,
  reason: string,
  opts?: { key?: string; hwid?: string; ip?: string; location?: string; details?: string }
) {
  const entry: AccessLog = {
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
    action,
    success,
    reason,
    key: opts?.key,
    hwid: opts?.hwid,
    ip: opts?.ip,
    location: opts?.location,
    details: opts?.details
  };
  db.logs.unshift(entry);
  if (db.logs.length > 500) {
    db.logs = db.logs.slice(0, 500);
  }
  saveDatabase();
}

// Generate secure session token
function generateToken(key: string, hwid: string): string {
  const ts = Date.now().toString();
  const signature = crypto
    .createHmac('sha256', db.jwtSecret)
    .update(`${key}:${hwid}:${ts}`)
    .digest('hex');
  return `${key}.${hwid}.${ts}.${signature}`;
}

// Verify session token
function verifyToken(token: string): { valid: boolean; key?: string; hwid?: string } {
  if (!token || typeof token !== 'string') return { valid: false };
  if (revokedSessionTokens.has(token)) return { valid: false };

  const parts = token.split('.');
  if (parts.length !== 4) return { valid: false };
  const [key, hwid, ts, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', db.jwtSecret)
    .update(`${key}:${hwid}:${ts}`)
    .digest('hex');
  if (expectedSig !== signature) return { valid: false };
  return { valid: true, key, hwid };
}

// Helper to check and auto-update key expiration
function checkExpiration(lic: LicenseRecord): boolean {
  if (lic.status === 'paused' || lic.status === 'revoked') {
    return false;
  }
  if (lic.expiresAt) {
    const expTime = new Date(lic.expiresAt).getTime();
    if (Date.now() > expTime) {
      lic.status = 'expired';
      saveDatabase();
      return false;
    }
  }
  return true;
}

export async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '10mb' }));

  // Helper to extract client IP
  const getClientIp = (req: Request) => {
    return (
      (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() ||
      req.socket.remoteAddress ||
      '127.0.0.1'
    );
  };

  // ----------------------------------------------------
  // SYSTEM STATUS & MAINTENANCE API (PUBLIC)
  // ----------------------------------------------------
  app.get('/api/system/status', (_req: Request, res: Response) => {
    res.json({
      maintenance: db.maintenance?.enabled || false,
      reason: db.maintenance?.reason || 'Site is under maintenance.',
      updatedAt: db.maintenance?.updatedAt || new Date().toISOString()
    });
  });

  // ----------------------------------------------------
  // PUBLIC CLIENT AUTH API
  // ----------------------------------------------------

  // Activate license with HWID
  app.post('/api/auth/activate', async (req: Request, res: Response): Promise<any> => {
    // 1. Check Global Website Kill Switch / Maintenance Lockdown
    if (db.maintenance && db.maintenance.enabled) {
      return res.status(503).json({
        maintenance: true,
        error: db.maintenance.reason || 'Website is currently stopped for emergency maintenance.'
      });
    }

    const { key, hwid, deviceInfo } = req.body;
    const ip = getClientIp(req);

    if (!key || !hwid) {
      return res.status(400).json({ error: 'License key and Device HWID are required' });
    }

    const cleanKey = String(key).trim().toUpperCase();
    const cleanHwid = String(hwid).trim();

    // Check if HWID is permanently banned
    if (db.bannedHwids && db.bannedHwids.includes(cleanHwid)) {
      logEvent('blocked', false, 'Access denied: Device HWID is permanently banned', { key: cleanKey, hwid: cleanHwid, ip });
      return res.status(403).json({
        error: 'Access Denied: This hardware device has been blacklisted by the administrator.',
        status: 'banned'
      });
    }

    const lic = db.licenses.find(l => l.key.toUpperCase() === cleanKey);
    if (!lic) {
      logEvent('blocked', false, 'Invalid license key attempt', { key: cleanKey, hwid: cleanHwid, ip });
      return res.status(404).json({ error: 'License key not found. Please verify and try again.' });
    }

    // Check if stopped/paused by admin
    if (lic.status === 'paused') {
      logEvent('blocked', false, 'Access blocked: License paused by administrator', { key: cleanKey, hwid: cleanHwid, ip });
      return res.status(403).json({
        error: 'This device license has been paused/stopped by the administrator.',
        status: 'paused'
      });
    }

    if (lic.status === 'revoked') {
      logEvent('blocked', false, 'Access blocked: License revoked', { key: cleanKey, hwid: cleanHwid, ip });
      return res.status(403).json({
        error: 'This license has been permanently revoked.',
        status: 'revoked'
      });
    }

    // Check expiration if already set
    if (lic.expiresAt && new Date(lic.expiresAt).getTime() < Date.now()) {
      lic.status = 'expired';
      saveDatabase();
      logEvent('blocked', false, 'Access blocked: License expired', { key: cleanKey, hwid: cleanHwid, ip });
      return res.status(403).json({
        error: 'This license has expired. Please contact support or renew.',
        status: 'expired'
      });
    }

    // HWID Binding Check - 1 Device Lock
    if (lic.boundHwid && lic.boundHwid !== cleanHwid) {
      logEvent('blocked', false, 'HWID Mismatch: Device unauthorized', {
        key: cleanKey,
        hwid: cleanHwid,
        ip,
        details: `Bound to ${lic.boundHwid}, attempted from ${cleanHwid}`
      });
      return res.status(403).json({
        error: `Access Denied: This license is locked to another hardware device (${lic.boundHwid}). Each key works on 1 device only. Contact the administrator to reset HWID.`,
        status: 'hwid_mismatch',
        boundHwid: lic.boundHwid
      });
    }

    // Resolve geographic location
    const location = await resolveLocation(ip, deviceInfo?.timezone);

    // First-time activation: bind to this HWID
    const now = new Date();
    if (!lic.boundHwid) {
      lic.boundHwid = cleanHwid;
      lic.boundDeviceInfo = deviceInfo || null;
      lic.boundIp = ip;
      lic.lastLocation = location;
      lic.activatedAt = now.toISOString();

      // Calculate expiration based on durationDays
      const expDate = new Date(now.getTime() + lic.durationDays * 24 * 60 * 60 * 1000);
      lic.expiresAt = expDate.toISOString();
      lic.status = 'active';
    } else {
      lic.lastLocation = location;
      if (deviceInfo) lic.boundDeviceInfo = deviceInfo;
    }

    lic.lastSeenAt = now.toISOString();
    saveDatabase();

    // Register into in-memory live tracking
    activeDevices.set(cleanHwid, {
      hwid: cleanHwid,
      key: cleanKey,
      ip,
      lastSeenAt: now.toISOString(),
      lastSeenTimestamp: now.getTime(),
      deviceInfo: deviceInfo || lic.boundDeviceInfo || {},
      location,
      currentAction: 'Unlocked Cash App simulator'
    });

    const token = generateToken(cleanKey, cleanHwid);

    logEvent('activate', true, 'Device successfully activated and locked to HWID', {
      key: cleanKey,
      hwid: cleanHwid,
      ip,
      location: `${location.city}, ${location.country}`,
      details: `Expires: ${lic.expiresAt}`
    });

    return res.json({
      success: true,
      token,
      key: lic.key,
      hwid: lic.boundHwid,
      expiresAt: lic.expiresAt,
      status: lic.status,
      notes: lic.notes,
      location
    });
  });

  // Verify existing session & heartbeat telemetry
  app.post('/api/auth/verify', async (req: Request, res: Response): Promise<any> => {
    // 1. Check Global Website Kill Switch
    if (db.maintenance && db.maintenance.enabled) {
      return res.status(503).json({
        valid: false,
        maintenance: true,
        error: db.maintenance.reason || 'Website is currently stopped for emergency maintenance.'
      });
    }

    const { token, key, hwid, deviceInfo } = req.body;
    const ip = getClientIp(req);

    if (!token && (!key || !hwid)) {
      return res.status(401).json({ valid: false, error: 'Missing token or credentials' });
    }

    let licKey = key;
    let licHwid = hwid;

    if (token) {
      const v = verifyToken(token);
      if (!v.valid) {
        return res.status(401).json({ valid: false, error: 'Session terminated or invalid' });
      }
      licKey = v.key;
      licHwid = v.hwid;
    }

    const cleanHwid = String(licHwid).trim();

    // Check if HWID is banned
    if (db.bannedHwids && db.bannedHwids.includes(cleanHwid)) {
      return res.status(403).json({ valid: false, error: 'Hardware banned', status: 'banned' });
    }

    const lic = db.licenses.find(l => l.key.toUpperCase() === String(licKey).toUpperCase());
    if (!lic) {
      return res.status(404).json({ valid: false, error: 'License key not found' });
    }

    if (lic.status === 'paused') {
      logEvent('blocked', false, 'Heartbeat stopped: License paused by admin', { key: lic.key, hwid: cleanHwid, ip });
      return res.status(403).json({ valid: false, error: 'Device paused by administrator', status: 'paused' });
    }

    if (lic.status === 'revoked') {
      return res.status(403).json({ valid: false, error: 'License revoked', status: 'revoked' });
    }

    if (!checkExpiration(lic)) {
      return res.status(403).json({ valid: false, error: 'License expired', status: 'expired' });
    }

    if (lic.boundHwid && lic.boundHwid !== cleanHwid) {
      return res.status(403).json({ valid: false, error: 'HWID mismatch', status: 'hwid_mismatch' });
    }

    const now = new Date();
    lic.lastSeenAt = now.toISOString();
    lic.boundIp = ip;

    // Resolve or update location
    const location = await resolveLocation(ip, deviceInfo?.timezone || lic.boundDeviceInfo?.timezone);
    lic.lastLocation = location;
    if (deviceInfo) lic.boundDeviceInfo = { ...(lic.boundDeviceInfo || {}), ...deviceInfo };

    saveDatabase();

    // Update in-memory live tracking
    activeDevices.set(cleanHwid, {
      hwid: cleanHwid,
      key: lic.key,
      ip,
      lastSeenAt: now.toISOString(),
      lastSeenTimestamp: now.getTime(),
      deviceInfo: lic.boundDeviceInfo || {},
      location,
      currentAction: 'Active in Cash App'
    });

    return res.json({
      valid: true,
      key: lic.key,
      hwid: lic.boundHwid,
      expiresAt: lic.expiresAt,
      status: lic.status,
      location
    });
  });

  // PROTECTED CASH APP APPLICATION BUNDLE
  // Only delivered to verified devices with a valid, active HWID session token!
  app.get('/api/auth/app-bundle', (req: Request, res: Response): any => {
    // 1. Check Global Website Kill Switch
    if (db.maintenance && db.maintenance.enabled) {
      return res.status(503).json({
        error: db.maintenance.reason || 'Website is stopped for emergency maintenance.'
      });
    }

    const authHeader = req.headers.authorization;
    let token = '';

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7);
    } else if (req.query.token) {
      token = String(req.query.token);
    }

    const ip = getClientIp(req);

    if (!token) {
      logEvent('blocked', false, 'App bundle request denied: No token provided', { ip });
      return res.status(401).json({ error: 'Access Denied: HWID License verification required to load Zyre' });
    }

    const v = verifyToken(token);
    if (!v.valid || !v.key || !v.hwid) {
      logEvent('blocked', false, 'App bundle request denied: Invalid token signature', { ip });
      return res.status(403).json({ error: 'Access Denied: Invalid or revoked session token' });
    }

    // Check if HWID is banned
    if (db.bannedHwids && db.bannedHwids.includes(v.hwid)) {
      return res.status(403).json({ error: 'Device permanently banned' });
    }

    const lic = db.licenses.find(l => l.key.toUpperCase() === v.key?.toUpperCase());
    if (!lic) {
      return res.status(404).json({ error: 'License record not found' });
    }

    if (lic.status === 'paused') {
      logEvent('blocked', false, 'App bundle denied: License paused by admin', { key: lic.key, hwid: v.hwid, ip });
      return res.status(403).json({ error: 'Device has been stopped by administrator' });
    }

    if (!checkExpiration(lic)) {
      logEvent('blocked', false, 'App bundle denied: License expired', { key: lic.key, hwid: v.hwid, ip });
      return res.status(403).json({ error: 'License expired' });
    }

    if (lic.boundHwid !== v.hwid) {
      logEvent('blocked', false, 'App bundle denied: HWID mismatch', { key: lic.key, hwid: v.hwid, ip });
      return res.status(403).json({ error: 'Device HWID mismatch' });
    }

    if (!fs.existsSync(BUNDLE_FILE)) {
      return res.status(500).json({ error: 'Core client bundle not ready on server' });
    }

    try {
      const bundleCode = fs.readFileSync(BUNDLE_FILE, 'utf-8');
      logEvent('app_request', true, 'Full Zyre Cash App bundle served to verified HWID', {
        key: lic.key,
        hwid: lic.boundHwid,
        ip
      });
      res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
      return res.send(bundleCode);
    } catch (e: any) {
      return res.status(500).json({ error: 'Error loading client bundle', message: e.message });
    }
  });

  // ----------------------------------------------------
  // ADMIN API ROUTES (Protected by Admin Key)
  // ----------------------------------------------------

  const adminAuth = (req: Request, res: Response, next: any): any => {
    const adminToken = req.headers['x-admin-key'] || req.query.adminKey;
    if (!adminToken || adminToken !== db.adminKey) {
      return res.status(401).json({ error: 'Unauthorized: Invalid Admin Secret Key' });
    }
    next();
  };

  // Admin login check
  app.post('/api/admin/login', (req: Request, res: Response): any => {
    const { adminKey } = req.body;
    if (!adminKey || adminKey !== db.adminKey) {
      logEvent('admin_change', false, 'Failed admin login attempt', { ip: getClientIp(req) });
      return res.status(401).json({ error: 'Invalid Admin Secret Key' });
    }
    logEvent('admin_change', true, 'Admin successfully logged into control panel', { ip: getClientIp(req) });
    return res.json({ success: true, message: 'Admin authenticated' });
  });

  // Get admin stats
  app.get('/api/admin/stats', adminAuth, (_req: Request, res: Response) => {
    db.licenses.forEach(checkExpiration);

    const now = Date.now();
    let onlineCount = 0;

    activeDevices.forEach(d => {
      if (now - d.lastSeenTimestamp < 60000) {
        onlineCount++;
      }
    });

    const total = db.licenses.length;
    const active = db.licenses.filter(l => l.status === 'active' && l.boundHwid).length;
    const unbound = db.licenses.filter(l => l.status === 'active' && !l.boundHwid).length;
    const paused = db.licenses.filter(l => l.status === 'paused').length;
    const expired = db.licenses.filter(l => l.status === 'expired').length;

    res.json({
      total,
      active,
      unbound,
      paused,
      expired,
      onlineNow: onlineCount,
      maintenance: db.maintenance,
      bannedCount: db.bannedHwids ? db.bannedHwids.length : 0,
      logsCount: db.logs.length
    });
  });

  // ----------------------------------------------------
  // LIVE RADAR & TELEMETRY TRACKING API
  // ----------------------------------------------------
  app.get('/api/admin/live-tracking', adminAuth, (_req: Request, res: Response) => {
    db.licenses.forEach(checkExpiration);

    const now = Date.now();
    const devicesList: any[] = [];
    const countryAgg: { [country: string]: { count: number; flag: string; countryCode: string } } = {};

    // Collect from all bound licenses and active sessions
    const processedHwids = new Set<string>();

    // 1. First add from in-memory active devices
    activeDevices.forEach(sess => {
      processedHwids.add(sess.hwid);
      const diffSec = Math.floor((now - sess.lastSeenTimestamp) / 1000);
      let status: 'online' | 'idle' | 'offline' = 'offline';
      if (diffSec < 60) status = 'online';
      else if (diffSec < 900) status = 'idle';

      const lic = db.licenses.find(l => l.boundHwid === sess.hwid);
      const isBanned = db.bannedHwids?.includes(sess.hwid) || false;

      // Country stats
      const cName = sess.location?.country || 'Unknown Country';
      if (!countryAgg[cName]) {
        countryAgg[cName] = {
          count: 0,
          flag: sess.location?.flag || '🌐',
          countryCode: sess.location?.countryCode || 'GL'
        };
      }
      countryAgg[cName].count++;

      devicesList.push({
        hwid: sess.hwid,
        key: sess.key,
        status,
        secondsAgo: diffSec,
        lastSeenAt: sess.lastSeenAt,
        ip: sess.ip,
        location: sess.location,
        deviceInfo: sess.deviceInfo,
        currentAction: sess.currentAction,
        licenseStatus: lic?.status || 'unlinked',
        licenseExpiresAt: lic?.expiresAt || null,
        durationDays: lic?.durationDays || 0,
        notes: lic?.notes || '',
        isBanned
      });
    });

    // 2. Add bound licenses not in current in-memory map
    db.licenses.forEach(lic => {
      if (lic.boundHwid && !processedHwids.has(lic.boundHwid)) {
        processedHwids.add(lic.boundHwid);
        const lastSeen = lic.lastSeenAt ? new Date(lic.lastSeenAt).getTime() : 0;
        const diffSec = lastSeen ? Math.floor((now - lastSeen) / 1000) : 999999;
        let status: 'online' | 'idle' | 'offline' = 'offline';
        if (diffSec < 60) status = 'online';
        else if (diffSec < 900) status = 'idle';

        const isBanned = db.bannedHwids?.includes(lic.boundHwid) || false;
        const loc = lic.lastLocation || resolveLocationFromTimezone(lic.boundDeviceInfo?.timezone);

        const cName = loc.country || 'Unknown Country';
        if (!countryAgg[cName]) {
          countryAgg[cName] = {
            count: 0,
            flag: loc.flag || '🌐',
            countryCode: loc.countryCode || 'GL'
          };
        }
        countryAgg[cName].count++;

        devicesList.push({
          hwid: lic.boundHwid,
          key: lic.key,
          status,
          secondsAgo: diffSec,
          lastSeenAt: lic.lastSeenAt,
          ip: lic.boundIp || 'Unknown IP',
          location: loc,
          deviceInfo: lic.boundDeviceInfo || {},
          currentAction: status === 'online' ? 'Active in Cash App' : 'Offline / Idle',
          licenseStatus: lic.status,
          licenseExpiresAt: lic.expiresAt,
          durationDays: lic.durationDays,
          notes: lic.notes,
          isBanned
        });
      }
    });

    // Sort by status (online first) then by most recent
    devicesList.sort((a, b) => {
      if (a.status === 'online' && b.status !== 'online') return -1;
      if (b.status === 'online' && a.status !== 'online') return 1;
      return a.secondsAgo - b.secondsAgo;
    });

    const onlineCount = devicesList.filter(d => d.status === 'online').length;
    const idleCount = devicesList.filter(d => d.status === 'idle').length;

    res.json({
      onlineCount,
      idleCount,
      totalDevices: devicesList.length,
      maintenance: db.maintenance,
      devices: devicesList,
      countries: Object.entries(countryAgg).map(([name, data]) => ({
        country: name,
        count: data.count,
        flag: data.flag,
        countryCode: data.countryCode
      }))
    });
  });

  // ----------------------------------------------------
  // EMERGENCY KILL SWITCH & MAINTENANCE LOCKDOWN API
  // ----------------------------------------------------
  app.post('/api/admin/maintenance/toggle', adminAuth, (req: Request, res: Response): any => {
    const { enabled, reason } = req.body;
    const newStatus = typeof enabled === 'boolean' ? enabled : !db.maintenance.enabled;

    db.maintenance.enabled = newStatus;
    if (reason && typeof reason === 'string') {
      db.maintenance.reason = reason.trim();
    }
    db.maintenance.updatedAt = new Date().toISOString();
    saveDatabase();

    logEvent(
      'admin_change',
      true,
      newStatus
        ? 'EMERGENCY LOCKDOWN ENGAGED - Website fully stopped'
        : 'Emergency lockdown disabled - Website resumed normal operation',
      {
        ip: getClientIp(req),
        details: db.maintenance.reason
      }
    );

    return res.json({
      success: true,
      maintenance: db.maintenance,
      message: newStatus
        ? 'Website has been fully STOPPED. All user access is locked out immediately.'
        : 'Website has been RESUMED. Users can access normally.'
    });
  });

  // ----------------------------------------------------
  // DEVICE SPECIFIC ACTIONS: KICK, PAUSE, BAN, RESET
  // ----------------------------------------------------

  // Kick / Force-disconnect Device
  app.post('/api/admin/devices/:hwid/kick', adminAuth, (req: Request, res: Response): any => {
    const { hwid } = req.params;
    const cleanHwid = String(hwid).trim();

    activeDevices.delete(cleanHwid);

    // Find and invalidate tokens for this HWID
    const lic = db.licenses.find(l => l.boundHwid === cleanHwid);
    if (lic) {
      const ts = Date.now().toString();
      // Generate a temporary blacklisted signature
      revokedSessionTokens.add(generateToken(lic.key, cleanHwid));
    }

    logEvent('kill_session', true, 'Admin kicked device session', { hwid: cleanHwid });
    return res.json({ success: true, message: `Device ${cleanHwid} kicked immediately.` });
  });

  // Toggle pause on device
  app.post('/api/admin/devices/:hwid/toggle-pause', adminAuth, (req: Request, res: Response): any => {
    const { hwid } = req.params;
    const cleanHwid = String(hwid).trim();
    const lic = db.licenses.find(l => l.boundHwid === cleanHwid);

    if (!lic) {
      return res.status(404).json({ error: 'No license found bound to this hardware ID' });
    }

    if (lic.status === 'active') {
      lic.status = 'paused';
      activeDevices.delete(cleanHwid);
      logEvent('admin_change', true, 'Device paused by administrator', { key: lic.key, hwid: cleanHwid });
    } else {
      lic.status = 'active';
      logEvent('admin_change', true, 'Device resumed by administrator', { key: lic.key, hwid: cleanHwid });
    }

    saveDatabase();
    return res.json({ success: true, status: lic.status, key: lic.key });
  });

  // Permanently Ban HWID
  app.post('/api/admin/devices/:hwid/ban', adminAuth, (req: Request, res: Response): any => {
    const { hwid } = req.params;
    const cleanHwid = String(hwid).trim();

    if (!db.bannedHwids) db.bannedHwids = [];
    if (!db.bannedHwids.includes(cleanHwid)) {
      db.bannedHwids.push(cleanHwid);
    }

    // Revoke license if bound
    const lic = db.licenses.find(l => l.boundHwid === cleanHwid);
    if (lic) {
      lic.status = 'revoked';
    }

    activeDevices.delete(cleanHwid);
    saveDatabase();

    logEvent('ban_device', true, 'Device HWID permanently blacklisted', { hwid: cleanHwid });
    return res.json({ success: true, message: `Hardware ID ${cleanHwid} has been permanently banned.` });
  });

  // Unban HWID
  app.post('/api/admin/devices/:hwid/unban', adminAuth, (req: Request, res: Response): any => {
    const { hwid } = req.params;
    const cleanHwid = String(hwid).trim();

    if (db.bannedHwids) {
      db.bannedHwids = db.bannedHwids.filter(h => h !== cleanHwid);
    }

    saveDatabase();
    logEvent('admin_change', true, 'Device HWID removed from ban list', { hwid: cleanHwid });
    return res.json({ success: true, message: `Hardware ID ${cleanHwid} unbanned.` });
  });

  // Reset HWID directly from Device Tracker
  app.post('/api/admin/devices/:hwid/reset', adminAuth, (req: Request, res: Response): any => {
    const { hwid } = req.params;
    const cleanHwid = String(hwid).trim();
    const lic = db.licenses.find(l => l.boundHwid === cleanHwid);

    if (!lic) {
      return res.status(404).json({ error: 'No license found for this device' });
    }

    lic.boundHwid = null;
    lic.boundDeviceInfo = null;
    lic.boundIp = null;
    lic.lastLocation = null;
    activeDevices.delete(cleanHwid);
    saveDatabase();

    logEvent('admin_change', true, 'HWID unbind reset executed', { key: lic.key, hwid: cleanHwid });
    return res.json({ success: true, message: 'Device unlinked from key. Key is now available for new device.' });
  });

  // ----------------------------------------------------
  // LICENSE KEYS MANAGEMENT
  // ----------------------------------------------------

  // Get all license keys
  app.get('/api/admin/keys', adminAuth, (_req: Request, res: Response) => {
    db.licenses.forEach(checkExpiration);
    res.json({ licenses: db.licenses });
  });

  // Generate new keys (single or batch)
  app.post('/api/admin/keys', adminAuth, (req: Request, res: Response): any => {
    const { durationDays = 30, durationType = 'months', notes = '', count = 1, prefix = 'ZYRE' } = req.body;

    const numKeys = Math.min(Math.max(parseInt(count, 10) || 1, 1), 50);
    const days = parseInt(durationDays, 10) || 30;

    const generated: LicenseRecord[] = [];

    for (let i = 0; i < numKeys; i++) {
      const part1 = crypto.randomBytes(2).toString('hex').toUpperCase();
      const part2 = crypto.randomBytes(2).toString('hex').toUpperCase();
      const part3 = crypto.randomBytes(2).toString('hex').toUpperCase();
      const keyStr = `${prefix}-${part1}-${part2}-${part3}`;

      const newLic: LicenseRecord = {
        id: `zyre_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        key: keyStr,
        status: 'active',
        durationDays: days,
        durationType: durationType || 'days',
        createdAt: new Date().toISOString(),
        activatedAt: null,
        expiresAt: null,
        boundHwid: null,
        boundDeviceInfo: null,
        boundIp: null,
        lastSeenAt: null,
        notes: notes || `Created on ${new Date().toLocaleDateString()}`
      };

      db.licenses.unshift(newLic);
      generated.push(newLic);
    }

    saveDatabase();
    logEvent('admin_change', true, `Generated ${numKeys} new license key(s) (${days} days)`, {
      details: generated.map(g => g.key).join(', ')
    });

    return res.json({ success: true, count: generated.length, keys: generated });
  });

  // Stop / Pause / Resume device
  app.post('/api/admin/keys/:id/toggle', adminAuth, (req: Request, res: Response): any => {
    const { id } = req.params;
    const lic = db.licenses.find(l => l.id === id || l.key === id);
    if (!lic) {
      return res.status(404).json({ error: 'License not found' });
    }

    if (lic.status === 'active') {
      lic.status = 'paused';
      if (lic.boundHwid) activeDevices.delete(lic.boundHwid);
      logEvent('admin_change', true, `Device stopped/paused by admin`, { key: lic.key, hwid: lic.boundHwid || '' });
    } else if (lic.status === 'paused') {
      lic.status = 'active';
      logEvent('admin_change', true, `Device resumed by admin`, { key: lic.key, hwid: lic.boundHwid || '' });
    }

    saveDatabase();
    return res.json({ success: true, status: lic.status, key: lic.key });
  });

  // Reset HWID binding (to transfer device)
  app.post('/api/admin/keys/:id/reset-hwid', adminAuth, (req: Request, res: Response): any => {
    const { id } = req.params;
    const lic = db.licenses.find(l => l.id === id || l.key === id);
    if (!lic) {
      return res.status(404).json({ error: 'License not found' });
    }

    const prevHwid = lic.boundHwid;
    if (prevHwid) activeDevices.delete(prevHwid);

    lic.boundHwid = null;
    lic.boundDeviceInfo = null;
    lic.boundIp = null;
    lic.lastLocation = null;
    saveDatabase();

    logEvent('admin_change', true, `HWID reset for license: unbound from device`, {
      key: lic.key,
      details: `Previous HWID was ${prevHwid}`
    });

    return res.json({ success: true, message: 'HWID reset successfully. Key can now be bound to a new device.', key: lic.key });
  });

  // Extend duration
  app.post('/api/admin/keys/:id/extend', adminAuth, (req: Request, res: Response): any => {
    const { id } = req.params;
    const { days = 30 } = req.body;
    const addDays = parseInt(days, 10) || 30;

    const lic = db.licenses.find(l => l.id === id || l.key === id);
    if (!lic) {
      return res.status(404).json({ error: 'License not found' });
    }

    const baseTime = lic.expiresAt ? Math.max(new Date(lic.expiresAt).getTime(), Date.now()) : Date.now();
    const newExpires = new Date(baseTime + addDays * 86400000).toISOString();

    lic.expiresAt = newExpires;
    lic.durationDays += addDays;
    if (lic.status === 'expired') {
      lic.status = 'active';
    }
    saveDatabase();

    logEvent('admin_change', true, `Extended license duration by ${addDays} days`, {
      key: lic.key,
      details: `New expiry: ${newExpires}`
    });

    return res.json({ success: true, expiresAt: lic.expiresAt, status: lic.status });
  });

  // Delete key
  app.delete('/api/admin/keys/:id', adminAuth, (req: Request, res: Response): any => {
    const { id } = req.params;
    const idx = db.licenses.findIndex(l => l.id === id || l.key === id);
    if (idx === -1) {
      return res.status(404).json({ error: 'License not found' });
    }

    const deleted = db.licenses.splice(idx, 1)[0];
    if (deleted.boundHwid) activeDevices.delete(deleted.boundHwid);
    saveDatabase();

    logEvent('admin_change', true, `License deleted permanently`, { key: deleted.key });
    return res.json({ success: true, message: 'License deleted' });
  });

  // Update notes
  app.put('/api/admin/keys/:id/notes', adminAuth, (req: Request, res: Response): any => {
    const { id } = req.params;
    const { notes } = req.body;
    const lic = db.licenses.find(l => l.id === id || l.key === id);
    if (!lic) {
      return res.status(404).json({ error: 'License not found' });
    }
    lic.notes = String(notes || '');
    saveDatabase();
    return res.json({ success: true, notes: lic.notes });
  });

  // Get logs
  app.get('/api/admin/logs', adminAuth, (_req: Request, res: Response) => {
    res.json({ logs: db.logs });
  });

  // Change Admin Key
  app.post('/api/admin/change-password', adminAuth, (req: Request, res: Response): any => {
    const { newAdminKey } = req.body;
    if (!newAdminKey || String(newAdminKey).trim().length < 4) {
      return res.status(400).json({ error: 'New admin key must be at least 4 characters long' });
    }
    db.adminKey = String(newAdminKey).trim();
    saveDatabase();
    logEvent('admin_change', true, 'Admin key updated', { ip: getClientIp(req) });
    return res.json({ success: true, message: 'Admin key changed successfully' });
  });

  // Export database backup
  app.get('/api/admin/export', adminAuth, (_req: Request, res: Response) => {
    res.setHeader('Content-Disposition', 'attachment; filename="zyre-database-backup.json"');
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify(db, null, 2));
  });

  // Import database backup
  app.post('/api/admin/import', adminAuth, (req: Request, res: Response): any => {
    const { database } = req.body;
    if (!database || !Array.isArray(database.licenses)) {
      return res.status(400).json({ error: 'Invalid database structure' });
    }
    db.licenses = database.licenses;
    if (database.adminKey) db.adminKey = database.adminKey;
    if (Array.isArray(database.logs)) db.logs = database.logs;
    if (database.maintenance) db.maintenance = database.maintenance;
    if (Array.isArray(database.bannedHwids)) db.bannedHwids = database.bannedHwids;
    saveDatabase();
    logEvent('admin_change', true, 'Database restored from backup file');
    return res.json({ success: true, message: 'Database imported successfully', totalKeys: db.licenses.length });
  });

  // Export standalone Key Gate HTML
  app.get('/api/admin/export-gate-html', adminAuth, (_req: Request, res: Response) => {
    const gateHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>Zyre Terminal - HWID Key Verification</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: #000; color: #fff; font-family: -apple-system, system-ui, sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
    .card { background: #0c0d10; border: 1px solid rgba(0, 214, 50, 0.25); border-radius: 20px; padding: 36px 30px; width: 100%; max-width: 440px; box-shadow: 0 20px 60px rgba(0,0,0,0.8), 0 0 40px rgba(0,214,50,0.1); }
    .logo { width: 56px; height: 56px; border-radius: 16px; background: rgba(0, 214, 50, 0.15); border: 1px solid rgba(0, 214, 50, 0.4); display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; }
    h1 { font-size: 22px; text-align: center; font-weight: 700; margin-bottom: 6px; letter-spacing: -0.5px; }
    p.sub { font-size: 13px; color: #888; text-align: center; margin-bottom: 24px; }
    .hwid-box { background: rgba(255,255,255,0.04); border: 1px dashed rgba(255,255,255,0.15); border-radius: 12px; padding: 12px 14px; margin-bottom: 20px; font-family: monospace; font-size: 12px; color: #00D632; display: flex; justify-content: space-between; align-items: center; }
    input { width: 100%; background: #16181e; border: 1px solid rgba(255,255,255,0.15); border-radius: 12px; padding: 16px; font-size: 16px; color: #fff; margin-bottom: 18px; outline: none; font-weight: 600; text-align: center; letter-spacing: 2px; }
    input:focus { border-color: #00D632; box-shadow: 0 0 15px rgba(0,214,50,0.25); }
    button { width: 100%; background: #00D632; color: #000; border: none; border-radius: 12px; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; }
    button:hover { opacity: 0.9; }
    .note { margin-top: 18px; font-size: 11px; color: #666; text-align: center; line-height: 1.5; }
  </style>
</head>
<body>
  <div class="card">
    <div class="logo">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#00D632" stroke-width="2.2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
    </div>
    <h1>Zyre Protected Portal</h1>
    <p class="sub">Hardware-bound access terminal</p>
    <div class="hwid-box">
      <span>DEVICE HWID</span>
      <span id="hwidVal">GENERATING...</span>
    </div>
    <input type="text" id="keyInput" placeholder="ZYRE-XXXX-XXXX-XXXX" />
    <button onclick="submitKey()">ACTIVATE ACCESS</button>
    <div class="note">This standalone terminal verifies your hardware signature with the central server.</div>
  </div>
  <script>
    const hwid = 'HWID-' + Math.random().toString(36).substring(2, 10).toUpperCase();
    document.getElementById('hwidVal').innerText = hwid;
    function submitKey() {
      const k = document.getElementById('keyInput').value;
      if (!k) return alert('Please enter key');
      alert('Forwarding to activation host: ' + k);
    }
  </script>
</body>
</html>`;
    res.setHeader('Content-Disposition', 'attachment; filename="zyre-gate-terminal.html"');
    res.setHeader('Content-Type', 'text/html');
    res.send(gateHtml);
  });

  // ----------------------------------------------------
  // VITE DEV MIDDLEWARE / STATIC SERVING
  // ----------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Zyre] Core Server running at http://0.0.0.0:${PORT}`);
    console.log(`[Zyre] Admin Portal: http://0.0.0.0:${PORT}/adminzyre (Default Key: ${db.adminKey})`);
  });
}

startServer().catch(err => {
  console.error('Fatal error starting Zyre server:', err);
});
