import React, { StrictMode } from 'react';
import * as ReactDOMClient from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Provide global access for secured bundles
(window as any).React = React;
(window as any).ReactDOM = ReactDOMClient;

ReactDOMClient.createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
