/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { getDeviceHwid, DeviceHardwareInfo } from './utils/hwid';
import { KeyGate } from './components/KeyGate';
import { AdminPortal } from './components/AdminPortal';
import { ZyreAppContainer } from './components/ZyreAppContainer';
import { ShieldAlert, RefreshCw, Lock } from 'lucide-react';

export default function App() {
  const [hardwareInfo, setHardwareInfo] = useState<DeviceHardwareInfo | null>(null);
  const [session, setSession] = useState<{
    token: string;
    key: string;
    expiresAt: string | null;
    boundHwid: string;
    notes?: string;
  } | null>(null);
  const [currentView, setCurrentView] = useState<'unlock' | 'app' | 'admin'>('unlock');
  const [lockError, setLockError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [maintenance, setMaintenance] = useState<{ enabled: boolean; reason: string } | null>(null);
  const [checkingMaintenance, setCheckingMaintenance] = useState(false);

  // Monitor URL path and hash changes for secret admin route: /adminzyre
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();

      // ONLY show admin portal when /adminzyre or #adminzyre is in the URL
      if (path === '/adminzyre' || hash === '#adminzyre') {
        setCurrentView('admin');
        return;
      }

      // Normal navigation
      if (currentView === 'admin') {
        if (session) {
          setCurrentView('app');
        } else {
          setCurrentView('unlock');
        }
      }
    };

    handleLocationChange();
    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, [session, currentView]);

  const checkSystemStatus = async () => {
    setCheckingMaintenance(true);
    try {
      const res = await fetch('/api/system/status');
      if (res.ok) {
        const data = await res.json();
        setMaintenance(data.maintenance ? { enabled: true, reason: data.reason } : null);
      }
    } catch {}
    finally {
      setCheckingMaintenance(false);
    }
  };

  // Initial Hardware Fingerprint and Session Verification
  useEffect(() => {
    let isCancelled = false;

    const init = async () => {
      try {
        // First check system maintenance
        const statusRes = await fetch('/api/system/status').catch(() => null);
        if (statusRes && statusRes.ok) {
          const statusData = await statusRes.json();
          if (statusData.maintenance) {
            setMaintenance({ enabled: true, reason: statusData.reason });
          }
        }

        const info = await getDeviceHwid();
        if (isCancelled) return;
        setHardwareInfo(info);

        const path = window.location.pathname.toLowerCase();
        const hash = window.location.hash.toLowerCase();

        // Secret Admin URL check
        if (path === '/adminzyre' || hash === '#adminzyre') {
          setCurrentView('admin');
          setIsInitializing(false);
          return;
        }

        // If on root '/', smoothly replace state with '/unlock'
        if (path === '/' && !window.location.search) {
          window.history.replaceState({}, '', '/unlock');
        }

        // Check for stored session in localStorage
        const storedToken = localStorage.getItem('zyre_session_token');
        const storedKey = localStorage.getItem('zyre_license_key');
        const storedExpires = localStorage.getItem('zyre_expires_at');

        if (storedToken && storedKey && info.hwid) {
          // Verify with server
          const res = await fetch('/api/auth/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              token: storedToken,
              key: storedKey,
              hwid: info.hwid,
              deviceInfo: {
                os: info.os,
                browser: info.browser,
                screen: info.screenRes,
                cores: info.cores,
                gpu: info.gpu,
                userAgent: info.userAgent,
                timezone: info.timezone,
                language: info.language
              }
            })
          });

          const data = await res.json();
          if (res.status === 503 || data.maintenance) {
            setMaintenance({ enabled: true, reason: data.error || 'System is stopped by administrator.' });
            setIsInitializing(false);
            return;
          }

          if (res.ok && data.valid) {
            setSession({
              token: storedToken,
              key: storedKey,
              expiresAt: data.expiresAt || storedExpires,
              boundHwid: info.hwid
            });
            setCurrentView('app');
          } else {
            // Invalid, expired, or paused
            localStorage.removeItem('zyre_session_token');
            if (data.error) {
              setLockError(data.error);
            }
            window.history.replaceState({}, '', '/unlock');
            setCurrentView('unlock');
          }
        } else {
          window.history.replaceState({}, '', '/unlock');
          setCurrentView('unlock');
        }
      } catch (e) {
        window.history.replaceState({}, '', '/unlock');
        setCurrentView('unlock');
      } finally {
        if (!isCancelled) setIsInitializing(false);
      }
    };

    init();

    return () => {
      isCancelled = true;
    };
  }, []);

  const handleActivateSuccess = (newSession: {
    token: string;
    key: string;
    expiresAt: string | null;
    boundHwid: string;
    notes?: string;
  }) => {
    setSession(newSession);
    setLockError(null);
    window.history.replaceState({}, '', '/');
    setCurrentView('app');
  };

  const handleLockOut = (reason: string) => {
    localStorage.removeItem('zyre_session_token');
    setSession(null);
    setLockError(reason);
    window.history.replaceState({}, '', '/unlock');
    setCurrentView('unlock');
  };

  const handleDeactivate = () => {
    localStorage.removeItem('zyre_session_token');
    localStorage.removeItem('zyre_license_key');
    localStorage.removeItem('zyre_expires_at');
    setSession(null);
    setLockError(null);
    window.history.replaceState({}, '', '/unlock');
    setCurrentView('unlock');
  };

  const handleBackFromAdmin = () => {
    if (session) {
      window.history.pushState({}, '', '/');
      setCurrentView('app');
    } else {
      window.history.pushState({}, '', '/unlock');
      setCurrentView('unlock');
    }
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center font-sans select-none">
        <div className="w-12 h-12 rounded-xl bg-[#00D632]/20 border border-[#00D632]/40 flex items-center justify-center animate-pulse mb-3">
          <div className="w-4 h-4 bg-[#00D632] rounded-full" />
        </div>
        <div className="text-xs font-mono tracking-widest text-[#00D632]">ZYRE INITIALIZING...</div>
      </div>
    );
  }

  // 1. ADMIN PORTAL takes precedence if user navigated to /adminzyre
  if (currentView === 'admin') {
    return <AdminPortal onBackToApp={handleBackFromAdmin} />;
  }

  // 2. EMERGENCY LOCKDOWN / STOPPED WEBSITE SCREEN
  if (maintenance?.enabled) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4 relative overflow-hidden font-sans select-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="w-full max-w-md bg-[#0e0f14] border border-red-500/30 rounded-3xl p-8 shadow-2xl relative z-10 text-center">
          <div className="w-16 h-16 rounded-2xl bg-red-950/60 border border-red-500/50 flex items-center justify-center mx-auto mb-5 shadow-[0_0_30px_rgba(239,68,68,0.2)]">
            <ShieldAlert className="w-8 h-8 text-red-500" />
          </div>

          <div className="flex items-center justify-center gap-2 mb-2">
            <h1 className="text-2xl font-black tracking-tight text-white">SYSTEM LOCKED</h1>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-red-950 text-red-400 border border-red-500/40 rounded-full uppercase">
              MAINTENANCE
            </span>
          </div>

          <p className="text-xs text-gray-400 mb-6 leading-relaxed">
            The administrator has suspended website access for maintenance or security.
          </p>

          <div className="bg-[#14161f] border border-red-500/20 rounded-2xl p-4 mb-6 text-left">
            <div className="text-[10px] font-bold text-red-400 tracking-wider uppercase mb-1">
              LOCKDOWN NOTICE
            </div>
            <div className="text-xs text-gray-200 leading-relaxed font-mono">
              {maintenance.reason || 'Service temporarily paused by administration.'}
            </div>
          </div>

          <button
            onClick={checkSystemStatus}
            disabled={checkingMaintenance}
            className="w-full bg-[#181a24] hover:bg-[#202330] border border-white/10 text-white font-bold py-3.5 rounded-2xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${checkingMaintenance ? 'animate-spin text-[#00D632]' : ''}`} />
            <span>{checkingMaintenance ? 'CHECKING STATUS...' : 'CHECK STATUS AGAIN'}</span>
          </button>
        </div>
      </div>
    );
  }

  // 3. UNLOCKED CASH APP SIMULATOR
  if (currentView === 'app' && session) {
    return (
      <ZyreAppContainer
        session={session}
        hardwareInfo={hardwareInfo}
        onLockOut={handleLockOut}
        onDeactivate={handleDeactivate}
      />
    );
  }

  // 4. KEY GATE TERMINAL
  return (
    <KeyGate
      hardwareInfo={hardwareInfo}
      onActivateSuccess={handleActivateSuccess}
      initialError={lockError}
    />
  );
}
