/**
 * Hardware ID (HWID) Fingerprint Generator
 * Gathers multi-factor browser and hardware characteristics to produce a unique,
 * stable hardware identifier locked to the user's specific device.
 */

export interface DeviceHardwareInfo {
  hwid: string;
  os: string;
  browser: string;
  screenRes: string;
  cores: number;
  gpu: string;
  timezone: string;
  memory?: string;
  userAgent: string;
  language?: string;
}

/**
 * Generates or retrieves cached HWID for the current device
 */
export async function getDeviceHwid(): Promise<DeviceHardwareInfo> {
  const cachedHwid = localStorage.getItem('zyre_device_hwid');
  const cachedInfo = localStorage.getItem('zyre_device_info');

  const info = await collectHardwareInfo();

  if (cachedHwid) {
    info.hwid = cachedHwid;
    return info;
  }

  // Store in localStorage for consistency
  localStorage.setItem('zyre_device_hwid', info.hwid);
  localStorage.setItem('zyre_device_info', JSON.stringify(info));

  return info;
}

/**
 * Collects hardware signals and hashes them
 */
async function collectHardwareInfo(): Promise<DeviceHardwareInfo> {
  const nav = typeof navigator !== 'undefined' ? navigator : ({} as any);
  const win = typeof window !== 'undefined' ? window : ({} as any);
  const scr = typeof screen !== 'undefined' ? screen : ({} as any);

  // 1. Screen & Display metrics
  const screenRes = `${scr.width || 0}x${scr.height || 0}x${scr.colorDepth || 24}@${win.devicePixelRatio || 1}`;

  // 2. CPU & Memory
  const cores = nav.hardwareConcurrency || 4;
  const memory = (nav as any).deviceMemory ? `${(nav as any).deviceMemory}GB` : '4GB';

  // 3. Timezone
  let timezone = 'UTC';
  try {
    timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  } catch {}

  // 4. WebGL GPU signature
  let gpu = 'Standard GPU';
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl && 'getExtension' in gl) {
      const debugInfo = (gl as any).getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        const renderer = (gl as any).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        const vendor = (gl as any).getParameter(debugInfo.UNMASKED_VENDOR_WEBGL);
        gpu = `${vendor} ~ ${renderer}`;
      }
    }
  } catch {}

  // 5. Canvas 2D entropy
  let canvasHash = '';
  try {
    const cvs = document.createElement('canvas');
    cvs.width = 240;
    cvs.height = 60;
    const ctx = cvs.getContext('2d');
    if (ctx) {
      ctx.textBaseline = 'top';
      ctx.font = "14px 'Arial', sans-serif";
      ctx.fillStyle = '#00D632';
      ctx.fillRect(10, 10, 80, 40);
      ctx.fillStyle = '#111';
      ctx.fillText('ZYRE-HWID-DEVICE-SIG-2026', 15, 20);
      ctx.shadowColor = 'rgba(0, 214, 50, 0.8)';
      ctx.shadowBlur = 8;
      ctx.fillText('VERIFIED', 40, 38);
      canvasHash = cvs.toDataURL().slice(-60);
    }
  } catch {}

  // 6. OS & Browser detection
  const ua = nav.userAgent || '';
  let os = 'Unknown OS';
  if (/Windows/i.test(ua)) os = 'Windows';
  else if (/Macintosh|Mac OS/i.test(ua)) os = 'macOS';
  else if (/iPhone|iPad|iPod/i.test(ua)) os = 'iOS';
  else if (/Android/i.test(ua)) os = 'Android';
  else if (/Linux/i.test(ua)) os = 'Linux';

  let browser = 'Browser';
  if (/Chrome|CriOS/i.test(ua) && !/Edg/i.test(ua)) browser = 'Chrome';
  else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';
  else if (/Firefox/i.test(ua)) browser = 'Firefox';
  else if (/Edg/i.test(ua)) browser = 'Edge';

  // Combine components into unique seed string
  const rawSeed = [
    os,
    browser,
    screenRes,
    cores,
    memory,
    gpu,
    timezone,
    canvasHash,
    nav.language || 'en',
    nav.platform || 'web'
  ].join(':::');

  // Compute SHA-256 hash using web crypto
  const hash = await sha256(rawSeed);
  const formattedHwid = `HWID-${hash.substring(0, 16).toUpperCase()}`;

  return {
    hwid: formattedHwid,
    os,
    browser,
    screenRes,
    cores,
    gpu,
    timezone,
    memory,
    userAgent: ua,
    language: nav.language || 'en-US'
  };
}

async function sha256(message: string): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const msgBuffer = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }
  // Fallback simple hash if subtle crypto is not available
  let h = 0x811c9dc5;
  for (let i = 0; i < message.length; i++) {
    h ^= message.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(16, '0') + 'a1b2c3d4e5f6';
}
