import React, { useEffect, useState, useRef } from 'react';
import * as ReactDOMClient from 'react-dom/client';
import { Shield, ChevronDown, Copy, Check, LogOut, AlertTriangle } from 'lucide-react';
import { DeviceHardwareInfo } from '../utils/hwid';

// Expose React and ReactDOM globally before any bundle evaluation
if (typeof window !== 'undefined') {
  (window as any).React = React;
  (window as any).ReactDOM = ReactDOMClient;
}

interface ZyreAppContainerProps {
  session: {
    token: string;
    key: string;
    expiresAt: string | null;
    boundHwid: string;
    notes?: string;
  };
  hardwareInfo: DeviceHardwareInfo | null;
  onLockOut: (reason: string) => void;
  onDeactivate: () => void;
}

export const ZyreAppContainer: React.FC<ZyreAppContainerProps> = ({
  session,
  hardwareInfo,
  onLockOut,
  onDeactivate
}) => {
  const [CashAppComp, setCashAppComp] = useState<React.ComponentType | null>(null);
  const [loadingBundle, setLoadingBundle] = useState<boolean>(true);
  const [bundleError, setBundleError] = useState<string | null>(null);
  const [showStatusMenu, setShowStatusMenu] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<boolean>(false);
  const heartbeatTimer = useRef<any>(null);

  // Fetch and instantiate the secured Cash App component
  useEffect(() => {
    let isCancelled = false;

    const loadSecuredBundle = async () => {
      setLoadingBundle(true);
      setBundleError(null);

      try {
        // Expose React runtime globals
        (window as any).React = React;
        (window as any).ReactDOM = ReactDOMClient;

        const res = await fetch('/api/auth/app-bundle', {
          headers: {
            Authorization: `Bearer ${session.token}`
          }
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || 'Failed to authorize and download application.');
        }

        const scriptText = await res.text();

        if (isCancelled) return;

        // Synchronously execute the bundle
        const runBundle = new Function(scriptText);
        runBundle();

        const Comp = (window as any).CashApp;
        if (Comp) {
          setCashAppComp(() => Comp);
          setLoadingBundle(false);
        } else {
          throw new Error('Application could not be initialized from the protected bundle.');
        }
      } catch (err: any) {
        if (!isCancelled) {
          setBundleError(err.message || 'Access Denied: Valid HWID License required.');
          setLoadingBundle(false);
        }
      }
    };

    loadSecuredBundle();

    return () => {
      isCancelled = true;
    };
  }, [session.token]);

  // Periodic heartbeat security checker
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const res = await fetch('/api/auth/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            token: session.token,
            key: session.key,
            hwid: session.boundHwid,
            deviceInfo: hardwareInfo ? {
              os: hardwareInfo.os,
              browser: hardwareInfo.browser,
              screen: hardwareInfo.screenRes,
              cores: hardwareInfo.cores,
              gpu: hardwareInfo.gpu,
              userAgent: hardwareInfo.userAgent,
              timezone: hardwareInfo.timezone,
              language: hardwareInfo.language
            } : undefined
          })
        });

        const data = await res.json();
        if (!res.ok || !data.valid) {
          clearInterval(heartbeatTimer.current);
          onLockOut(data.error || 'Device license stopped or expired.');
        }
      } catch {}
    };

    // Check every 25 seconds
    heartbeatTimer.current = setInterval(checkStatus, 25000);

    return () => {
      if (heartbeatTimer.current) clearInterval(heartbeatTimer.current);
    };
  }, [session, onLockOut]);

  // Calculate days left string
  const getRemainingDaysText = () => {
    if (!session.expiresAt) return 'Active';
    const diff = new Date(session.expiresAt).getTime() - Date.now();
    if (diff <= 0) return 'Expired';
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days >= 3000) return 'Lifetime';
    if (days === 0) return 'Expires Today';
    return `${days} Days Left`;
  };

  const handleCopyKey = () => {
    navigator.clipboard.writeText(session.key);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="relative w-full h-full min-h-screen bg-black overflow-hidden font-sans">
      {/* Floating Status Pill Header */}
      <div className="fixed top-2 right-2 sm:right-4 z-[9999999]">
        <div className="relative">
          <button
            onClick={() => setShowStatusMenu(!showStatusMenu)}
            className="flex items-center gap-2 bg-[#0d0e12]/90 hover:bg-[#14161f] border border-[#00D632]/40 backdrop-blur-md px-3 py-1.5 rounded-full text-xs text-white shadow-[0_4px_16px_rgba(0,0,0,0.8),0_0_12px_rgba(0,214,50,0.2)] transition-all cursor-pointer"
          >
            <span className="w-2 h-2 rounded-full bg-[#00D632] animate-pulse" />
            <span className="font-bold text-[11px] text-[#00D632] tracking-wider">ZYRE ACTIVE</span>
            <span className="text-[10px] text-gray-400 border-l border-white/10 pl-2">
              {getRemainingDaysText()}
            </span>
            <ChevronDown className="w-3 h-3 text-gray-400" />
          </button>

          {/* Dropdown Menu */}
          {showStatusMenu && (
            <div className="absolute right-0 mt-2 w-72 bg-[#0e1015] border border-white/10 rounded-2xl p-4 shadow-2xl z-50 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-white/5 mb-3">
                <span className="font-bold text-white flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-[#00D632]" />
                  HWID Device Lock
                </span>
                <span className="text-[10px] bg-[#00D632]/20 text-[#00D632] px-2 py-0.5 rounded font-mono font-bold">
                  VERIFIED
                </span>
              </div>

              <div className="space-y-2 mb-4 font-mono text-[11px]">
                <div>
                  <div className="text-[10px] text-gray-500">LICENSE KEY</div>
                  <div className="flex items-center justify-between text-white bg-black/40 px-2 py-1 rounded border border-white/5">
                    <span>{session.key}</span>
                    <button onClick={handleCopyKey} className="text-[#00D632] hover:text-white">
                      {copiedKey ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-gray-500">BOUND HARDWARE ID</div>
                  <div className="text-[#00D632] bg-black/40 px-2 py-1 rounded border border-white/5 truncate">
                    {session.boundHwid}
                  </div>
                </div>

                {session.expiresAt && (
                  <div>
                    <div className="text-[10px] text-gray-500">EXPIRES</div>
                    <div className="text-gray-300">
                      {new Date(session.expiresAt).toLocaleDateString()} ({getRemainingDaysText()})
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-2 border-t border-white/5">
                <button
                  onClick={() => {
                    setShowStatusMenu(false);
                    onDeactivate();
                  }}
                  className="w-full flex items-center justify-between p-2 rounded-xl bg-red-950/30 hover:bg-red-900/40 text-red-300 transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <LogOut className="w-3.5 h-3.5" />
                    Lock / Change Key
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Loading state while loading bundle */}
      {loadingBundle && (
        <div className="absolute inset-0 bg-black flex flex-col items-center justify-center p-4 z-50">
          <div className="w-16 h-16 rounded-2xl bg-[#00D632]/10 border border-[#00D632]/30 flex items-center justify-center mb-4 animate-pulse">
            <Shield className="w-8 h-8 text-[#00D632]" />
          </div>
          <div className="text-white font-bold text-lg mb-1 tracking-tight">VERIFYING HWID CLEARANCE</div>
          <p className="text-xs text-gray-400 mb-4">Loading secured simulation visual...</p>
          <div className="w-36 h-1 bg-[#161821] rounded-full overflow-hidden">
            <div className="w-full h-full bg-[#00D632] animate-pulse" />
          </div>
        </div>
      )}

      {/* Bundle Error state */}
      {bundleError && (
        <div className="absolute inset-0 bg-black flex flex-col items-center justify-center p-6 z-50">
          <div className="w-16 h-16 rounded-2xl bg-red-950/50 border border-red-500/40 flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-lg font-bold text-white mb-2">ACCESS TERMINATED</h2>
          <p className="text-xs text-red-300 max-w-sm text-center mb-6 leading-relaxed">
            {bundleError}
          </p>
          <button
            onClick={onDeactivate}
            className="px-6 py-3 bg-[#00D632] text-black font-bold rounded-xl text-xs cursor-pointer"
          >
            Return to Key Unlock
          </button>
        </div>
      )}

      {/* Render the Cash App visual directly */}
      {CashAppComp && <CashAppComp />}
    </div>
  );
};
