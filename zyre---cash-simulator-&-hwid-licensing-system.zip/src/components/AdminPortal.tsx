import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Shield,
  Key,
  Users,
  Clock,
  Ban,
  RotateCcw,
  Plus,
  Search,
  Copy,
  Check,
  Trash2,
  Calendar,
  AlertTriangle,
  Download,
  Upload,
  RefreshCw,
  LogOut,
  ArrowLeft,
  Activity,
  Cpu,
  Lock,
  Unlock,
  Settings,
  Info,
  Radio,
  Globe,
  MapPin,
  Power,
  Wifi,
  WifiOff,
  ShieldAlert,
  Crosshair,
  Monitor,
  Smartphone,
  Laptop,
  AlertOctagon
} from 'lucide-react';
import { LicenseRecord, AccessLog } from '../../server';

interface AdminPortalProps {
  onBackToApp: () => void;
}

interface LiveTrackingDevice {
  hwid: string;
  key: string;
  status: 'online' | 'idle' | 'offline';
  secondsAgo: number;
  lastSeenAt: string | null;
  ip: string;
  location: {
    city: string;
    region: string;
    country: string;
    countryCode: string;
    flag: string;
    isp?: string;
    lat?: number;
    lon?: number;
  };
  deviceInfo: {
    os?: string;
    browser?: string;
    screen?: string;
    gpu?: string;
    cores?: number;
    timezone?: string;
    userAgent?: string;
  };
  currentAction: string;
  licenseStatus: string;
  licenseExpiresAt: string | null;
  durationDays: number;
  notes: string;
  isBanned: boolean;
}

interface CountryStat {
  country: string;
  count: number;
  flag: string;
  countryCode: string;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ onBackToApp }) => {
  const [adminKey, setAdminKey] = useState<string>(() => sessionStorage.getItem('zyre_admin_key') || '');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [loginInput, setLoginInput] = useState<string>('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState<boolean>(false);

  // Data states
  const [stats, setStats] = useState<any>(null);
  const [licenses, setLicenses] = useState<LicenseRecord[]>([]);
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [activeTab, setActiveTab] = useState<'tracking' | 'licenses' | 'killswitch' | 'logs' | 'settings'>('tracking');
  const [loadingData, setLoadingData] = useState<boolean>(false);

  // Live Tracking state
  const [liveDevices, setLiveDevices] = useState<LiveTrackingDevice[]>([]);
  const [countries, setCountries] = useState<CountryStat[]>([]);
  const [onlineCount, setOnlineCount] = useState<number>(0);
  const [autoRefreshLive, setAutoRefreshLive] = useState<boolean>(true);
  const [trackingFilter, setTrackingFilter] = useState<'all' | 'online' | 'idle' | 'offline'>('all');
  const [trackingSearch, setTrackingSearch] = useState<string>('');

  // Emergency Kill Switch / Maintenance state
  const [maintenanceEnabled, setMaintenanceEnabled] = useState<boolean>(false);
  const [maintenanceReason, setMaintenanceReason] = useState<string>('System is under emergency maintenance. Access suspended.');
  const [killswitchLoading, setKillswitchLoading] = useState<boolean>(false);
  const [killswitchNotice, setKillswitchNotice] = useState<string | null>(null);

  // Filters for Keys
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'unbound' | 'paused' | 'expired'>('all');

  // Generator modal
  const [isGenerateOpen, setIsGenerateOpen] = useState<boolean>(false);
  const [genDurationPreset, setGenDurationPreset] = useState<string>('30');
  const [genCustomDays, setGenCustomDays] = useState<number>(30);
  const [genUnit, setGenUnit] = useState<'days' | 'months' | 'years' | 'lifetime'>('months');
  const [genCount, setGenCount] = useState<number>(1);
  const [genNotes, setGenNotes] = useState<string>('');
  const [generatedResult, setGeneratedResult] = useState<LicenseRecord[] | null>(null);

  // Extend Modal
  const [extendModalKey, setExtendModalKey] = useState<LicenseRecord | null>(null);
  const [extendDays, setExtendDays] = useState<number>(30);

  // Device Detail Modal
  const [deviceDetailKey, setDeviceDetailKey] = useState<LicenseRecord | null>(null);

  // Settings
  const [newPasswordInput, setNewPasswordInput] = useState<string>('');
  const [passwordMsg, setPasswordMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Copied notifications
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const autoRefreshTimerRef = useRef<any>(null);

  // Initial check on mount
  useEffect(() => {
    if (adminKey) {
      verifyAdminKey(adminKey);
    }
  }, []);

  // Auto-refresh interval for live tracking
  useEffect(() => {
    if (!isAuthenticated || !autoRefreshLive) {
      if (autoRefreshTimerRef.current) clearInterval(autoRefreshTimerRef.current);
      return;
    }

    autoRefreshTimerRef.current = setInterval(() => {
      fetchLiveTracking(adminKey, false);
      fetchStatsOnly(adminKey);
    }, 5000);

    return () => {
      if (autoRefreshTimerRef.current) clearInterval(autoRefreshTimerRef.current);
    };
  }, [isAuthenticated, autoRefreshLive, adminKey]);

  const verifyAdminKey = async (key: string) => {
    setLoginLoading(true);
    setLoginError(null);
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminKey: key })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setIsAuthenticated(true);
        setAdminKey(key);
        sessionStorage.setItem('zyre_admin_key', key);
        fetchAllData(key);
      } else {
        setIsAuthenticated(false);
        sessionStorage.removeItem('zyre_admin_key');
        setLoginError(data.error || 'Invalid Admin Key');
      }
    } catch {
      setLoginError('Could not reach server');
    } finally {
      setLoginLoading(false);
    }
  };

  const fetchLiveTracking = async (keyToUse = adminKey, showLoading = true) => {
    if (!keyToUse) return;
    if (showLoading) setLoadingData(true);
    try {
      const res = await fetch('/api/admin/live-tracking', {
        headers: { 'x-admin-key': keyToUse }
      });
      if (res.ok) {
        const data = await res.json();
        setLiveDevices(data.devices || []);
        setCountries(data.countries || []);
        setOnlineCount(data.onlineCount || 0);
        if (data.maintenance) {
          setMaintenanceEnabled(data.maintenance.enabled);
          setMaintenanceReason(data.maintenance.reason);
        }
      }
    } catch (e) {
      console.error('Error fetching live tracking:', e);
    } finally {
      if (showLoading) setLoadingData(false);
    }
  };

  const fetchStatsOnly = async (keyToUse = adminKey) => {
    if (!keyToUse) return;
    try {
      const res = await fetch('/api/admin/stats', { headers: { 'x-admin-key': keyToUse } });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
        if (data.maintenance) {
          setMaintenanceEnabled(data.maintenance.enabled);
        }
      }
    } catch {}
  };

  const fetchAllData = async (keyToUse = adminKey) => {
    if (!keyToUse) return;
    setLoadingData(true);
    try {
      const headers = { 'x-admin-key': keyToUse };

      const [resStats, resKeys, resLogs, resTracking] = await Promise.all([
        fetch('/api/admin/stats', { headers }),
        fetch('/api/admin/keys', { headers }),
        fetch('/api/admin/logs', { headers }),
        fetch('/api/admin/live-tracking', { headers })
      ]);

      if (resStats.ok) {
        const s = await resStats.json();
        setStats(s);
        if (s.maintenance) {
          setMaintenanceEnabled(s.maintenance.enabled);
          setMaintenanceReason(s.maintenance.reason);
        }
      }
      if (resKeys.ok) {
        const kData = await resKeys.json();
        setLicenses(kData.licenses || []);
      }
      if (resLogs.ok) {
        const lData = await resLogs.json();
        setLogs(lData.logs || []);
      }
      if (resTracking.ok) {
        const tData = await resTracking.json();
        setLiveDevices(tData.devices || []);
        setCountries(tData.countries || []);
        setOnlineCount(tData.onlineCount || 0);
      }
    } catch (e) {
      console.error('Failed to load admin data:', e);
    } finally {
      setLoadingData(false);
    }
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginInput.trim()) {
      setLoginError('Please enter the Admin Key');
      return;
    }
    verifyAdminKey(loginInput.trim());
  };

  const handleLogout = () => {
    sessionStorage.removeItem('zyre_admin_key');
    setIsAuthenticated(false);
    setAdminKey('');
    setLoginInput('');
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // ----------------------------------------------------
  // EMERGENCY KILL SWITCH: STOP WEBSITE FULLY
  // ----------------------------------------------------
  const handleToggleEmergencyKillswitch = async (forcedState?: boolean) => {
    const newState = forcedState !== undefined ? forcedState : !maintenanceEnabled;
    const confirmMsg = newState
      ? 'CRITICAL WARNING: Are you sure you want to FULLY STOP THE WEBSITE?\n\nAll current sessions will be immediately terminated, and any visitor trying to access will see the Emergency Maintenance Lockout screen.'
      : 'Resume website and allow users to access and unlock with their license keys?';

    if (!confirm(confirmMsg)) return;

    setKillswitchLoading(true);
    setKillswitchNotice(null);

    try {
      const res = await fetch('/api/admin/maintenance/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          enabled: newState,
          reason: maintenanceReason
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setMaintenanceEnabled(data.maintenance.enabled);
        setMaintenanceReason(data.maintenance.reason);
        setKillswitchNotice(data.message);
        fetchAllData();
      } else {
        alert(data.error || 'Failed to update system lockdown status.');
      }
    } catch {
      alert('Could not communicate with server.');
    } finally {
      setKillswitchLoading(false);
    }
  };

  // ----------------------------------------------------
  // DEVICE CONTROLS: KICK, STOP, BAN, RESET
  // ----------------------------------------------------
  const handleKickDevice = async (hwid: string) => {
    if (!confirm(`Kick device ${hwid}? This will immediately terminate their current session and force them out.`)) return;

    try {
      const res = await fetch(`/api/admin/devices/${encodeURIComponent(hwid)}/kick`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchLiveTracking(adminKey, false);
      }
    } catch {
      alert('Error kicking device.');
    }
  };

  const handleToggleDevicePause = async (hwid: string) => {
    try {
      const res = await fetch(`/api/admin/devices/${encodeURIComponent(hwid)}/toggle-pause`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchLiveTracking(adminKey, false);
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error changing device status.');
    }
  };

  const handleBanDeviceHwid = async (hwid: string) => {
    if (!confirm(`PERMANENT BAN: Are you sure you want to blacklist HWID ${hwid}?\n\nThis physical device will NEVER be able to activate or run any Zyre license key on this website.`)) return;

    try {
      const res = await fetch(`/api/admin/devices/${encodeURIComponent(hwid)}/ban`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchLiveTracking(adminKey, false);
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error banning device.');
    }
  };

  const handleUnbanDeviceHwid = async (hwid: string) => {
    try {
      const res = await fetch(`/api/admin/devices/${encodeURIComponent(hwid)}/unban`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchLiveTracking(adminKey, false);
      }
    } catch {
      alert('Error unbanning device.');
    }
  };

  const handleResetDeviceHwid = async (hwid: string, keyStr: string) => {
    if (!confirm(`Reset HWID for key ${keyStr}? The license will be unbound from ${hwid} and can be activated on a new device.`)) return;

    try {
      const res = await fetch(`/api/admin/devices/${encodeURIComponent(hwid)}/reset`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error resetting HWID.');
    }
  };

  // Toggle License Key Stop / Resume
  const handleToggleLicense = async (lic: LicenseRecord) => {
    try {
      const res = await fetch(`/api/admin/keys/${lic.id}/toggle`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error updating status');
    }
  };

  // Reset HWID from License row
  const handleResetHwid = async (lic: LicenseRecord) => {
    if (!confirm(`Reset HWID for key ${lic.key}? The key will be unbound from device ${lic.boundHwid || ''} and can be activated on a new device.`)) {
      return;
    }
    try {
      const res = await fetch(`/api/admin/keys/${lic.id}/reset-hwid`, {
        method: 'POST',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error resetting HWID');
    }
  };

  // Extend duration
  const handleExtendDuration = async () => {
    if (!extendModalKey) return;
    try {
      const res = await fetch(`/api/admin/keys/${extendModalKey.id}/extend`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ days: extendDays })
      });
      if (res.ok) {
        setExtendModalKey(null);
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error extending key');
    }
  };

  // Delete key
  const handleDeleteKey = async (lic: LicenseRecord) => {
    if (!confirm(`Permanently delete license key ${lic.key}? This action cannot be undone.`)) {
      return;
    }
    try {
      const res = await fetch(`/api/admin/keys/${lic.id}`, {
        method: 'DELETE',
        headers: { 'x-admin-key': adminKey }
      });
      if (res.ok) {
        fetchAllData(adminKey);
      }
    } catch {
      alert('Error deleting key');
    }
  };

  // Generate Keys Submit
  const handleGenerateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    let days = genCustomDays;
    if (genDurationPreset !== 'custom') {
      days = parseInt(genDurationPreset, 10);
    }

    try {
      const res = await fetch('/api/admin/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({
          durationDays: days,
          durationType: genUnit,
          count: genCount,
          notes: genNotes
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setGeneratedResult(data.keys);
        fetchAllData(adminKey);
      } else {
        alert(data.error || 'Failed to generate keys');
      }
    } catch {
      alert('Error generating keys');
    }
  };

  // Change Admin Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPasswordInput || newPasswordInput.trim().length < 4) {
      setPasswordMsg({ text: 'Admin key must be at least 4 characters', error: true });
      return;
    }
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey },
        body: JSON.stringify({ newAdminKey: newPasswordInput.trim() })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setAdminKey(newPasswordInput.trim());
        sessionStorage.setItem('zyre_admin_key', newPasswordInput.trim());
        setPasswordMsg({ text: 'Admin Key updated successfully! Please remember it.', error: false });
        setNewPasswordInput('');
      } else {
        setPasswordMsg({ text: data.error || 'Failed to update key', error: true });
      }
    } catch {
      setPasswordMsg({ text: 'Network error', error: true });
    }
  };

  // Filtered Tracking Devices
  const filteredTrackingDevices = useMemo(() => {
    return liveDevices.filter(d => {
      if (trackingFilter !== 'all' && d.status !== trackingFilter) return false;
      if (trackingSearch) {
        const q = trackingSearch.toLowerCase();
        const inKey = d.key.toLowerCase().includes(q);
        const inHwid = d.hwid.toLowerCase().includes(q);
        const inCity = d.location?.city?.toLowerCase().includes(q);
        const inCountry = d.location?.country?.toLowerCase().includes(q);
        const inIp = d.ip.toLowerCase().includes(q);
        const inOs = d.deviceInfo?.os?.toLowerCase().includes(q);
        return inKey || inHwid || inCity || inCountry || inIp || inOs;
      }
      return true;
    });
  }, [liveDevices, trackingFilter, trackingSearch]);

  // Filtered Licenses
  const filteredLicenses = useMemo(() => {
    return licenses.filter(lic => {
      if (statusFilter === 'active' && (lic.status !== 'active' || !lic.boundHwid)) return false;
      if (statusFilter === 'unbound' && (lic.status !== 'active' || lic.boundHwid)) return false;
      if (statusFilter === 'paused' && lic.status !== 'paused') return false;
      if (statusFilter === 'expired' && lic.status !== 'expired') return false;

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const matchKey = lic.key.toLowerCase().includes(q);
        const matchHwid = lic.boundHwid ? lic.boundHwid.toLowerCase().includes(q) : false;
        const matchNotes = lic.notes ? lic.notes.toLowerCase().includes(q) : false;
        const matchIp = lic.boundIp ? lic.boundIp.toLowerCase().includes(q) : false;
        return matchKey || matchHwid || matchNotes || matchIp;
      }
      return true;
    });
  }, [licenses, statusFilter, searchQuery]);

  // LOGIN SCREEN (if not authenticated)
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4 relative font-sans select-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#00D632]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="w-full max-w-md bg-[#0d0e12] border border-[#222] rounded-3xl p-8 shadow-2xl relative z-10 backdrop-blur-xl">
          <div className="flex flex-col items-center text-center mb-6">
            <div className="w-16 h-16 rounded-2xl bg-[#00D632]/10 border border-[#00D632]/30 flex items-center justify-center mb-4 shadow-[0_0_25px_rgba(0,214,50,0.2)]">
              <Shield className="w-8 h-8 text-[#00D632]" />
            </div>
            <h1 className="text-2xl font-black tracking-tight text-white mb-1">ZYRE ADMIN CONSOLE</h1>
            <p className="text-xs text-gray-400">Master Authentication Portal</p>
          </div>

          {loginError && (
            <div className="mb-4 bg-red-950/40 border border-red-500/40 rounded-2xl p-3 text-xs text-red-200 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-gray-300 mb-2">ADMIN SECRET KEY</label>
              <input
                type="password"
                value={loginInput}
                onChange={(e) => setLoginInput(e.target.value)}
                placeholder="Enter Admin Key"
                autoFocus
                className="w-full bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-2xl py-3.5 px-4 text-center font-mono text-base text-white placeholder-gray-600 outline-none transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={loginLoading}
              className="w-full bg-[#00D632] hover:bg-[#00c02d] text-black font-bold py-3.5 rounded-2xl text-xs tracking-wider uppercase transition-all shadow-[0_4px_16px_rgba(0,214,50,0.3)] flex items-center justify-center gap-2 cursor-pointer"
            >
              {loginLoading ? 'AUTHENTICATING...' : 'ENTER ADMIN CONSOLE'}
            </button>
          </form>

          <div className="mt-6 pt-5 border-t border-white/5 flex items-center justify-end text-xs text-gray-500">
            <button
              type="button"
              onClick={onBackToApp}
              className="text-gray-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Portal
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ----------------------------------------------------
  // AUTHENTICATED ADMIN DASHBOARD
  // ----------------------------------------------------
  return (
    <div className="min-h-screen bg-black text-white font-sans flex flex-col">
      {/* Top Admin Navigation Header */}
      <header className="border-b border-white/10 bg-[#0c0d12]/90 sticky top-0 z-40 backdrop-blur-md px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#00D632]/20 border border-[#00D632]/40 flex items-center justify-center">
              <Shield className="w-4 h-4 text-[#00D632]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-base tracking-tight">ZYRE COMMAND</span>
                <span className="text-[10px] bg-[#00D632]/20 text-[#00D632] px-2 py-0.5 rounded font-mono font-bold">
                  MASTER v3.0
                </span>
                {maintenanceEnabled && (
                  <span className="text-[10px] bg-red-600/30 text-red-400 border border-red-500/40 px-2 py-0.5 rounded font-bold animate-pulse flex items-center gap-1">
                    <AlertOctagon className="w-3 h-3" />
                    SITE FULLY STOPPED
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Quick Header Actions */}
          <div className="flex items-center gap-3">
            {/* Master Emergency Kill Switch Quick Button */}
            <button
              onClick={() => handleToggleEmergencyKillswitch()}
              disabled={killswitchLoading}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                maintenanceEnabled
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]'
                  : 'bg-[#181a24] hover:bg-red-950/40 border border-white/10 text-gray-300 hover:text-red-400'
              }`}
              title="Stop or resume all website traffic instantly"
            >
              <Power className={`w-3.5 h-3.5 ${maintenanceEnabled ? 'animate-spin' : ''}`} />
              <span>{maintenanceEnabled ? 'RESUME WEBSITE' : 'STOP WEBSITE FULLY'}</span>
            </button>

            <button
              onClick={() => fetchAllData(adminKey)}
              disabled={loadingData}
              className="p-2 rounded-xl bg-[#161821] hover:bg-[#1e2230] text-gray-300 hover:text-white transition-colors cursor-pointer"
              title="Refresh Data"
            >
              <RefreshCw className={`w-4 h-4 ${loadingData ? 'animate-spin text-[#00D632]' : ''}`} />
            </button>

            <button
              onClick={onBackToApp}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#161821] hover:bg-[#1e2230] text-xs text-gray-300 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Exit Console</span>
            </button>

            <button
              onClick={handleLogout}
              className="p-2 rounded-xl bg-red-950/30 hover:bg-red-900/40 text-red-400 transition-colors cursor-pointer"
              title="Logout"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3 gap-2 overflow-x-auto">
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('tracking')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'tracking'
                  ? 'bg-[#00D632] text-black shadow-[0_0_20px_rgba(0,214,50,0.3)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Live Radar & Telemetry</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                activeTab === 'tracking' ? 'bg-black text-[#00D632]' : 'bg-[#00D632]/20 text-[#00D632]'
              }`}>
                {onlineCount} LIVE
              </span>
            </button>

            <button
              onClick={() => setActiveTab('licenses')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'licenses'
                  ? 'bg-[#00D632] text-black shadow-[0_0_20px_rgba(0,214,50,0.3)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>Key Generator & Licenses</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                activeTab === 'licenses' ? 'bg-black text-[#00D632]' : 'bg-white/10 text-gray-300'
              }`}>
                {licenses.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('killswitch')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'killswitch'
                  ? 'bg-red-600 text-white shadow-[0_0_20px_rgba(239,68,68,0.3)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Power className="w-3.5 h-3.5" />
              <span>Emergency Lockdown</span>
              {maintenanceEnabled && (
                <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('logs')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'logs'
                  ? 'bg-[#00D632] text-black shadow-[0_0_20px_rgba(0,214,50,0.3)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Security Logs</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-[#00D632] text-black shadow-[0_0_20px_rgba(0,214,50,0.3)]'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Settings</span>
            </button>
          </div>

          {activeTab === 'licenses' && (
            <button
              onClick={() => setIsGenerateOpen(true)}
              className="bg-[#00D632] hover:bg-[#00c02d] text-black font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(0,214,50,0.25)] shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Generate Key</span>
            </button>
          )}
        </div>

        {/* ==================================================== */}
        {/* TAB 1: LIVE RADAR & TELEMETRY TRACKING */}
        {/* ==================================================== */}
        {activeTab === 'tracking' && (
          <div className="space-y-6">
            {/* Top Radar Status Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-gray-500 font-semibold uppercase tracking-wider">LIVE ONLINE NOW</div>
                  <div className="text-2xl font-black text-[#00D632] flex items-center gap-2 mt-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00D632] animate-pulse" />
                    {onlineCount} Devices
                  </div>
                  <div className="text-[10px] text-gray-400 mt-1">Active ping &lt; 60 seconds</div>
                </div>
                <div className="w-12 h-12 rounded-xl bg-[#00D632]/10 border border-[#00D632]/30 flex items-center justify-center">
                  <Radio className="w-6 h-6 text-[#00D632] animate-pulse" />
                </div>
              </div>

              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-gray-500 font-semibold uppercase tracking-wider">BOUND HARDWARE IDs</div>
                  <div className="text-2xl font-black text-white mt-1">{liveDevices.length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Total physical devices locked</div>
                </div>
                <div className="w-12 h-12 rounded-xl bg-blue-950/40 border border-blue-500/30 flex items-center justify-center">
                  <Cpu className="w-6 h-6 text-blue-400" />
                </div>
              </div>

              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-gray-500 font-semibold uppercase tracking-wider">COUNTRIES ACTIVE</div>
                  <div className="text-2xl font-black text-white mt-1">{countries.length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Global geographic distribution</div>
                </div>
                <div className="w-12 h-12 rounded-xl bg-purple-950/40 border border-purple-500/30 flex items-center justify-center">
                  <Globe className="w-6 h-6 text-purple-400" />
                </div>
              </div>

              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-4 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-gray-500 font-semibold uppercase tracking-wider">SYSTEM STATUS</div>
                  <div className={`text-base font-black mt-1 ${maintenanceEnabled ? 'text-red-400' : 'text-[#00D632]'}`}>
                    {maintenanceEnabled ? 'STOPPED (LOCKED)' : 'OPERATIONAL'}
                  </div>
                  <div className="text-[10px] text-gray-400 mt-1">
                    {maintenanceEnabled ? 'All traffic paused' : 'Hardware lock enforcing'}
                  </div>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  maintenanceEnabled ? 'bg-red-950/40 border border-red-500/30' : 'bg-[#00D632]/10 border border-[#00D632]/30'
                }`}>
                  <ShieldAlert className={`w-6 h-6 ${maintenanceEnabled ? 'text-red-400' : 'text-[#00D632]'}`} />
                </div>
              </div>
            </div>

            {/* Geographic Distribution Bar */}
            {countries.length > 0 && (
              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-4">
                <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-[#00D632]" />
                  Active Locations By Country
                </div>
                <div className="flex flex-wrap gap-2">
                  {countries.map(c => (
                    <div key={c.country} className="bg-[#14161f] border border-white/5 px-3 py-1.5 rounded-xl text-xs flex items-center gap-2">
                      <span className="text-base">{c.flag}</span>
                      <span className="text-white font-medium">{c.country}</span>
                      <span className="bg-[#00D632]/20 text-[#00D632] px-2 py-0.5 rounded-full text-[10px] font-mono font-bold">
                        {c.count} device{c.count > 1 ? 's' : ''}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tracking Controls & Search */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0d0e12] border border-white/10 p-3 rounded-2xl">
              <div className="flex items-center gap-2 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={trackingSearch}
                    onChange={(e) => setTrackingSearch(e.target.value)}
                    placeholder="Search by HWID, Key, Country, City, or IP..."
                    className="w-full bg-[#161821] border border-white/5 focus:border-[#00D632] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-gray-500 outline-none"
                  />
                </div>

                <div className="flex items-center gap-1 bg-[#161821] p-1 rounded-xl text-xs border border-white/5">
                  <button
                    onClick={() => setTrackingFilter('all')}
                    className={`px-2.5 py-1 rounded-lg transition-all ${
                      trackingFilter === 'all' ? 'bg-[#00D632] text-black font-bold' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    All ({liveDevices.length})
                  </button>
                  <button
                    onClick={() => setTrackingFilter('online')}
                    className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 ${
                      trackingFilter === 'online' ? 'bg-[#00D632] text-black font-bold' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00D632]" />
                    Online ({liveDevices.filter(d => d.status === 'online').length})
                  </button>
                  <button
                    onClick={() => setTrackingFilter('idle')}
                    className={`px-2.5 py-1 rounded-lg transition-all ${
                      trackingFilter === 'idle' ? 'bg-yellow-500 text-black font-bold' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Idle ({liveDevices.filter(d => d.status === 'idle').length})
                  </button>
                  <button
                    onClick={() => setTrackingFilter('offline')}
                    className={`px-2.5 py-1 rounded-lg transition-all ${
                      trackingFilter === 'offline' ? 'bg-gray-600 text-white font-bold' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    Offline ({liveDevices.filter(d => d.status === 'offline').length})
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setAutoRefreshLive(!autoRefreshLive)}
                  className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
                    autoRefreshLive
                      ? 'bg-[#00D632]/10 border-[#00D632]/40 text-[#00D632]'
                      : 'bg-[#161821] border-white/10 text-gray-400'
                  }`}
                >
                  <Activity className={`w-3.5 h-3.5 ${autoRefreshLive ? 'animate-pulse' : ''}`} />
                  <span>{autoRefreshLive ? 'LIVE RADAR AUTO-POLL (5s)' : 'RADAR PAUSED'}</span>
                </button>

                <button
                  onClick={() => fetchLiveTracking(adminKey)}
                  className="p-2 rounded-xl bg-[#161821] hover:bg-[#1e2230] text-gray-300 hover:text-white border border-white/5 cursor-pointer"
                  title="Scan Now"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Live Devices Feed */}
            {filteredTrackingDevices.length === 0 ? (
              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-12 text-center">
                <Crosshair className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white mb-1">No Active Hardware Signals Detected</h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto">
                  When a user enters a license key on the unlock gate, their hardware fingerprint, location, and telemetry will appear here in real time.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTrackingDevices.map((dev) => (
                  <div
                    key={dev.hwid}
                    className={`bg-[#0d0e12] border rounded-2xl p-4 transition-all ${
                      dev.status === 'online'
                        ? 'border-[#00D632]/30 shadow-[0_0_20px_rgba(0,214,50,0.05)]'
                        : dev.status === 'idle'
                        ? 'border-yellow-500/20'
                        : 'border-white/5'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                      {/* Left: Device & Location Details */}
                      <div className="space-y-2 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          {/* Online Status Badge */}
                          <div className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider ${
                            dev.status === 'online'
                              ? 'bg-[#00D632]/20 text-[#00D632] border border-[#00D632]/40'
                              : dev.status === 'idle'
                              ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/40'
                              : 'bg-gray-800 text-gray-400 border border-gray-700'
                          }`}>
                            <span className={`w-2 h-2 rounded-full ${
                              dev.status === 'online' ? 'bg-[#00D632] animate-pulse' : dev.status === 'idle' ? 'bg-yellow-400' : 'bg-gray-500'
                            }`} />
                            <span className="uppercase">{dev.status}</span>
                            <span className="border-l border-current/30 pl-1 font-mono text-[9px]">
                              {dev.secondsAgo < 60 ? `${dev.secondsAgo}s ago` : `${Math.floor(dev.secondsAgo / 60)}m ago`}
                            </span>
                          </div>

                          {/* Country & City Location */}
                          <div className="flex items-center gap-1.5 bg-[#14161f] border border-white/5 px-2.5 py-0.5 rounded-full text-xs text-white">
                            <span className="text-sm">{dev.location?.flag || '🌐'}</span>
                            <span className="font-semibold">{dev.location?.city || 'Unknown City'}</span>
                            {dev.location?.country && (
                              <span className="text-gray-400">, {dev.location.country}</span>
                            )}
                          </div>

                          {/* IP Address */}
                          <div className="font-mono text-[11px] text-gray-400 bg-black/40 px-2 py-0.5 rounded border border-white/5">
                            IP: {dev.ip}
                          </div>

                          {dev.isBanned && (
                            <span className="bg-red-950 text-red-400 border border-red-500/50 px-2 py-0.5 rounded text-[10px] font-bold">
                              BANNED HWID
                            </span>
                          )}
                        </div>

                        {/* Middle: HWID and Key */}
                        <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
                          <div className="flex items-center gap-1.5">
                            <span className="text-gray-500">HWID:</span>
                            <span className="text-[#00D632] font-bold bg-black/50 px-2 py-0.5 rounded border border-[#00D632]/20 select-all">
                              {dev.hwid}
                            </span>
                            <button
                              onClick={() => handleCopy(dev.hwid, dev.hwid)}
                              className="text-gray-400 hover:text-white"
                              title="Copy HWID"
                            >
                              {copiedKey === dev.hwid ? <Check className="w-3.5 h-3.5 text-[#00D632]" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <span className="text-gray-500">KEY:</span>
                            <span className="text-white font-bold bg-black/50 px-2 py-0.5 rounded border border-white/10 select-all">
                              {dev.key}
                            </span>
                            <button
                              onClick={() => handleCopy(dev.key, dev.key)}
                              className="text-gray-400 hover:text-white"
                              title="Copy Key"
                            >
                              {copiedKey === dev.key ? <Check className="w-3.5 h-3.5 text-[#00D632]" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                          </div>

                          {dev.notes && (
                            <span className="text-gray-400 font-sans text-[11px] italic">
                              "{dev.notes}"
                            </span>
                          )}
                        </div>

                        {/* Specs Pill: OS, Browser, GPU, Screen */}
                        <div className="flex flex-wrap items-center gap-2 text-[11px] text-gray-400 pt-1">
                          <span className="bg-[#161821] px-2 py-0.5 rounded border border-white/5 flex items-center gap-1">
                            <Monitor className="w-3 h-3 text-gray-400" />
                            {dev.deviceInfo?.os || 'OS'} · {dev.deviceInfo?.browser || 'Browser'}
                          </span>
                          {dev.deviceInfo?.screen && (
                            <span className="bg-[#161821] px-2 py-0.5 rounded border border-white/5">
                              {dev.deviceInfo.screen.split('@')[0]}
                            </span>
                          )}
                          {dev.deviceInfo?.gpu && (
                            <span className="bg-[#161821] px-2 py-0.5 rounded border border-white/5 text-[10px] text-gray-400 truncate max-w-xs">
                              GPU: {dev.deviceInfo.gpu.split('~')[0]}
                            </span>
                          )}
                          {dev.deviceInfo?.timezone && (
                            <span className="bg-[#161821] px-2 py-0.5 rounded border border-white/5 text-[10px]">
                              TZ: {dev.deviceInfo.timezone}
                            </span>
                          )}
                          {dev.location?.isp && (
                            <span className="bg-[#161821] px-2 py-0.5 rounded border border-white/5 text-[10px] text-gray-400">
                              ISP: {dev.location.isp}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Right: Live Action Buttons */}
                      <div className="flex flex-wrap lg:flex-nowrap items-center gap-2 w-full lg:w-auto shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-white/5">
                        {/* Kick / Force Disconnect */}
                        <button
                          onClick={() => handleKickDevice(dev.hwid)}
                          className="flex-1 lg:flex-none px-3 py-1.5 rounded-xl bg-yellow-950/30 hover:bg-yellow-900/40 text-yellow-300 border border-yellow-500/20 text-xs font-semibold flex items-center justify-center gap-1 transition-all cursor-pointer"
                          title="Instantly terminate current session"
                        >
                          <WifiOff className="w-3.5 h-3.5" />
                          <span>Kick Session</span>
                        </button>

                        {/* Stop Device (Pause) */}
                        <button
                          onClick={() => handleToggleDevicePause(dev.hwid)}
                          className={`flex-1 lg:flex-none px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                            dev.licenseStatus === 'paused'
                              ? 'bg-[#00D632]/20 hover:bg-[#00D632]/30 text-[#00D632] border border-[#00D632]/40'
                              : 'bg-red-950/30 hover:bg-red-900/40 text-red-300 border border-red-500/20'
                          }`}
                          title="Halt device license access"
                        >
                          {dev.licenseStatus === 'paused' ? (
                            <>
                              <Unlock className="w-3.5 h-3.5" />
                              <span>Resume</span>
                            </>
                          ) : (
                            <>
                              <Lock className="w-3.5 h-3.5" />
                              <span>Stop Device</span>
                            </>
                          )}
                        </button>

                        {/* Reset HWID Binding */}
                        <button
                          onClick={() => handleResetDeviceHwid(dev.hwid, dev.key)}
                          className="flex-1 lg:flex-none px-3 py-1.5 rounded-xl bg-[#161821] hover:bg-[#1e2230] text-gray-300 hover:text-white border border-white/10 text-xs font-semibold flex items-center justify-center gap-1 transition-all cursor-pointer"
                          title="Unbind HWID from key so it can be used on another device"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Reset HWID</span>
                        </button>

                        {/* Ban HWID */}
                        <button
                          onClick={() => (dev.isBanned ? handleUnbanDeviceHwid(dev.hwid) : handleBanDeviceHwid(dev.hwid))}
                          className={`flex-1 lg:flex-none p-1.5 rounded-xl text-xs font-semibold flex items-center justify-center transition-all cursor-pointer ${
                            dev.isBanned
                              ? 'bg-gray-800 text-gray-300'
                              : 'bg-red-950/40 hover:bg-red-900 text-red-400 border border-red-500/30'
                          }`}
                          title={dev.isBanned ? 'Unban HWID' : 'Permanently Ban HWID'}
                        >
                          <Ban className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 2: KEY GENERATOR & LICENSES */}
        {/* ==================================================== */}
        {activeTab === 'licenses' && (
          <div className="space-y-6">
            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0d0e12] border border-white/10 p-3 rounded-2xl">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search keys, HWID, or notes..."
                  className="w-full bg-[#161821] border border-white/5 focus:border-[#00D632] rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-gray-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-1 bg-[#161821] p-1 rounded-xl text-xs border border-white/5 overflow-x-auto">
                {(['all', 'active', 'unbound', 'paused', 'expired'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setStatusFilter(tab)}
                    className={`px-3 py-1 rounded-lg uppercase tracking-wider text-[11px] font-bold transition-all cursor-pointer ${
                      statusFilter === tab ? 'bg-[#00D632] text-black shadow-sm' : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Licenses Table */}
            {filteredLicenses.length === 0 ? (
              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-12 text-center">
                <Key className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                <h3 className="text-base font-bold text-white mb-1">No Licenses Found</h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto mb-4">
                  {searchQuery ? 'No license matches your search criteria.' : 'No customer keys have been generated yet.'}
                </p>
                <button
                  onClick={() => setIsGenerateOpen(true)}
                  className="bg-[#00D632] text-black font-bold px-4 py-2 rounded-xl text-xs cursor-pointer inline-flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" /> Generate New Key
                </button>
              </div>
            ) : (
              <div className="bg-[#0d0e12] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#14161f] text-gray-400 border-b border-white/5 uppercase tracking-wider text-[10px]">
                      <tr>
                        <th className="py-3 px-4">License Key</th>
                        <th className="py-3 px-4">Bound HWID & Location</th>
                        <th className="py-3 px-4">Duration & Expiry</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 font-mono">
                      {filteredLicenses.map((lic) => (
                        <tr key={lic.id} className="hover:bg-white/[0.02] transition-colors">
                          {/* Key Column */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2">
                              <span className="text-white font-bold tracking-wider">{lic.key}</span>
                              <button
                                onClick={() => handleCopy(lic.key, lic.id)}
                                className="text-gray-500 hover:text-[#00D632] transition-colors"
                                title="Copy Key"
                              >
                                {copiedKey === lic.id ? <Check className="w-3.5 h-3.5 text-[#00D632]" /> : <Copy className="w-3.5 h-3.5" />}
                              </button>
                            </div>
                            {lic.notes && (
                              <div className="text-[10px] text-gray-500 font-sans mt-0.5 truncate max-w-xs">
                                {lic.notes}
                              </div>
                            )}
                          </td>

                          {/* HWID & Location */}
                          <td className="py-3 px-4">
                            {lic.boundHwid ? (
                              <div>
                                <div className="text-[#00D632] font-semibold flex items-center gap-1.5">
                                  <Cpu className="w-3 h-3 text-[#00D632]" />
                                  <span className="truncate max-w-[150px]">{lic.boundHwid}</span>
                                </div>
                                {lic.lastLocation && (
                                  <div className="text-[10px] text-gray-400 font-sans flex items-center gap-1 mt-0.5">
                                    <span>{lic.lastLocation.flag || '🌐'}</span>
                                    <span>{lic.lastLocation.city}, {lic.lastLocation.country}</span>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-gray-500 italic text-[11px] font-sans">
                                Unbound (Locks on first use)
                              </span>
                            )}
                          </td>

                          {/* Expiry */}
                          <td className="py-3 px-4 font-sans text-xs">
                            <div className="text-gray-300 font-medium">
                              {lic.durationDays >= 3000 ? 'Lifetime' : `${lic.durationDays} Days`}
                            </div>
                            <div className="text-[10px] text-gray-500">
                              {lic.expiresAt
                                ? `Expires: ${new Date(lic.expiresAt).toLocaleDateString()}`
                                : 'Not yet activated'}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3 px-4">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              lic.status === 'active' && lic.boundHwid
                                ? 'bg-[#00D632]/20 text-[#00D632] border border-[#00D632]/30'
                                : lic.status === 'active'
                                ? 'bg-blue-950/40 text-blue-400 border border-blue-500/30'
                                : lic.status === 'paused'
                                ? 'bg-yellow-950/40 text-yellow-400 border border-yellow-500/30'
                                : 'bg-red-950/40 text-red-400 border border-red-500/30'
                            }`}>
                              {lic.status === 'active' && !lic.boundHwid ? 'UNBOUND' : lic.status}
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Pause / Resume */}
                              <button
                                onClick={() => handleToggleLicense(lic)}
                                className={`p-1.5 rounded-lg text-xs transition-colors ${
                                  lic.status === 'paused'
                                    ? 'bg-[#00D632]/20 hover:bg-[#00D632]/30 text-[#00D632]'
                                    : 'bg-[#1a1c26] hover:bg-yellow-950/50 text-yellow-400'
                                }`}
                                title={lic.status === 'paused' ? 'Resume Key' : 'Stop / Pause Device'}
                              >
                                {lic.status === 'paused' ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                              </button>

                              {/* Reset HWID */}
                              {lic.boundHwid && (
                                <button
                                  onClick={() => handleResetHwid(lic)}
                                  className="p-1.5 rounded-lg bg-[#1a1c26] hover:bg-blue-950/50 text-blue-400 transition-colors"
                                  title="Reset HWID (unbind device)"
                                >
                                  <RotateCcw className="w-3.5 h-3.5" />
                                </button>
                              )}

                              {/* Extend */}
                              <button
                                onClick={() => {
                                  setExtendModalKey(lic);
                                  setExtendDays(30);
                                }}
                                className="p-1.5 rounded-lg bg-[#1a1c26] hover:bg-purple-950/50 text-purple-400 transition-colors"
                                title="Extend Duration"
                              >
                                <Calendar className="w-3.5 h-3.5" />
                              </button>

                              {/* Delete */}
                              <button
                                onClick={() => handleDeleteKey(lic)}
                                className="p-1.5 rounded-lg bg-[#1a1c26] hover:bg-red-950/50 text-red-400 transition-colors"
                                title="Delete License"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 3: EMERGENCY KILL SWITCH / STOP WEBSITE FULLY */}
        {/* ==================================================== */}
        {activeTab === 'killswitch' && (
          <div className="space-y-6 max-w-3xl mx-auto">
            {/* Emergency Lockdown Banner */}
            <div className={`rounded-3xl p-6 sm:p-8 border transition-all ${
              maintenanceEnabled
                ? 'bg-red-950/40 border-red-500/50 shadow-[0_0_40px_rgba(239,68,68,0.2)]'
                : 'bg-[#0d0e12] border-white/10'
            }`}>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-white/10">
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    maintenanceEnabled
                      ? 'bg-red-900/60 border border-red-500 text-red-400 shadow-[0_0_20px_rgba(239,68,68,0.4)]'
                      : 'bg-white/5 border border-white/10 text-gray-400'
                  }`}>
                    <Power className={`w-8 h-8 ${maintenanceEnabled ? 'text-red-400 animate-pulse' : ''}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-xl font-black text-white">MASTER EMERGENCY KILL SWITCH</h2>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider ${
                        maintenanceEnabled
                          ? 'bg-red-600 text-white animate-pulse'
                          : 'bg-[#00D632]/20 text-[#00D632]'
                      }`}>
                        {maintenanceEnabled ? 'SYSTEM STOPPED' : 'SYSTEM ONLINE'}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1">
                      Instantly cut off all website access for every user. Nobody can unlock or run the application.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleToggleEmergencyKillswitch()}
                  disabled={killswitchLoading}
                  className={`w-full sm:w-auto px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-wider transition-all shadow-xl cursor-pointer ${
                    maintenanceEnabled
                      ? 'bg-[#00D632] hover:bg-[#00c02d] text-black shadow-[0_0_25px_rgba(0,214,50,0.4)]'
                      : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_25px_rgba(239,68,68,0.4)]'
                  }`}
                >
                  {killswitchLoading
                    ? 'PROCESSING...'
                    : maintenanceEnabled
                    ? 'RESUME WEBSITE OPERATION'
                    : 'STOP WEBSITE FULLY (LOCKDOWN)'}
                </button>
              </div>

              {killswitchNotice && (
                <div className="mt-4 p-3 bg-white/5 border border-white/10 rounded-xl text-xs text-[#00D632] flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>{killswitchNotice}</span>
                </div>
              )}

              {/* Maintenance Reason Editor */}
              <div className="mt-6 space-y-3">
                <label className="block text-xs font-semibold text-gray-300 uppercase tracking-wider">
                  VISITOR LOCKDOWN NOTICE MESSAGE
                </label>
                <p className="text-[11px] text-gray-500">
                  This message is displayed to visitors when they try to access the website while it is stopped.
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={maintenanceReason}
                    onChange={(e) => setMaintenanceReason(e.target.value)}
                    placeholder="e.g. Scheduled system upgrade. Service will resume shortly."
                    className="flex-1 bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-xl px-4 py-3 text-xs text-white placeholder-gray-600 outline-none"
                  />
                  <button
                    onClick={() => handleToggleEmergencyKillswitch(maintenanceEnabled)}
                    className="px-4 py-2 bg-[#1a1c26] hover:bg-[#222533] border border-white/10 text-white text-xs font-bold rounded-xl cursor-pointer"
                  >
                    Save Notice
                  </button>
                </div>
              </div>
            </div>

            {/* How It Works Notice */}
            <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-6 space-y-3 text-xs text-gray-400">
              <div className="font-bold text-white flex items-center gap-2">
                <Info className="w-4 h-4 text-[#00D632]" />
                How Emergency Lockdown Works
              </div>
              <ul className="list-disc list-inside space-y-1.5 text-[11px] leading-relaxed">
                <li>When enabled, all API endpoints for activation, verification, and app-bundle deliver a <code className="text-red-400">503 Service Suspended</code> error.</li>
                <li>All connected users are immediately kicked out from the Cash App simulator to the emergency lockout screen within seconds.</li>
                <li>The admin portal at <code className="text-[#00D632]">/adminzyre</code> remains accessible exclusively to you so you can monitor status and resume service anytime.</li>
              </ul>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 4: SECURITY & AUDIT LOGS */}
        {/* ==================================================== */}
        {activeTab === 'logs' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white">Real-Time Security & Audit Trail</h3>
                <p className="text-xs text-gray-400">Monitoring all activations, heartbeats, kicks, and security alerts</p>
              </div>
              <button
                onClick={() => fetchAllData(adminKey)}
                className="px-3 py-1.5 rounded-xl bg-[#161821] hover:bg-[#1e2230] text-xs text-gray-300 hover:text-white flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Logs</span>
              </button>
            </div>

            <div className="bg-[#0d0e12] border border-white/10 rounded-2xl overflow-hidden">
              <div className="divide-y divide-white/5 max-h-[600px] overflow-y-auto font-mono text-xs">
                {logs.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">No logs recorded yet.</div>
                ) : (
                  logs.map((log) => (
                    <div key={log.id} className="p-3.5 hover:bg-white/[0.02] flex items-start justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${
                            log.success ? 'bg-[#00D632]' : 'bg-red-500'
                          }`} />
                          <span className="font-bold text-white uppercase text-[11px]">{log.action}</span>
                          <span className="text-gray-500 text-[10px]">
                            {new Date(log.timestamp).toLocaleTimeString()} · {new Date(log.timestamp).toLocaleDateString()}
                          </span>
                        </div>
                        <div className="text-gray-300 font-sans text-xs">{log.reason}</div>
                        {(log.key || log.hwid || log.ip) && (
                          <div className="text-[10px] text-gray-500 flex flex-wrap gap-3 pt-0.5">
                            {log.key && <span>KEY: <span className="text-white">{log.key}</span></span>}
                            {log.hwid && <span>HWID: <span className="text-[#00D632]">{log.hwid}</span></span>}
                            {log.ip && <span>IP: <span className="text-gray-400">{log.ip}</span></span>}
                            {log.location && <span>LOC: <span className="text-blue-300">{log.location}</span></span>}
                          </div>
                        )}
                      </div>

                      {log.details && (
                        <div className="text-[10px] text-gray-500 text-right shrink-0 max-w-xs truncate">
                          {log.details}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 5: SETTINGS & BACKUPS */}
        {/* ==================================================== */}
        {activeTab === 'settings' && (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Change Admin Password */}
            <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-6">
              <h3 className="text-base font-bold text-white mb-1">Change Admin Secret Key</h3>
              <p className="text-xs text-gray-400 mb-4">
                Update the master password used to log in at <code className="text-[#00D632]">/adminzyre</code>.
              </p>

              {passwordMsg && (
                <div className={`p-3 rounded-xl mb-4 text-xs ${
                  passwordMsg.error ? 'bg-red-950/40 text-red-200 border border-red-500/40' : 'bg-green-950/40 text-green-200 border border-green-500/40'
                }`}>
                  {passwordMsg.text}
                </div>
              )}

              <form onSubmit={handleChangePassword} className="space-y-3">
                <input
                  type="password"
                  value={newPasswordInput}
                  onChange={(e) => setNewPasswordInput(e.target.value)}
                  placeholder="New Admin Key (min 4 characters)"
                  className="w-full bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-xl px-4 py-3 text-xs text-white placeholder-gray-500 outline-none"
                />
                <button
                  type="submit"
                  className="w-full bg-[#00D632] hover:bg-[#00c02d] text-black font-bold py-3 rounded-xl text-xs uppercase tracking-wider cursor-pointer"
                >
                  Update Admin Key
                </button>
              </form>
            </div>

            {/* Database Backup & Export */}
            <div className="bg-[#0d0e12] border border-white/10 rounded-2xl p-6 space-y-4">
              <h3 className="text-base font-bold text-white mb-1">Backup & Standalone Gate HTML</h3>
              <p className="text-xs text-gray-400">
                Download a JSON backup of all licenses and logs, or export the standalone terminal gate HTML.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href="/api/admin/export-gate-html"
                  download="zyre-gate-terminal.html"
                  className="p-3.5 bg-[#161821] hover:bg-[#1e2230] border border-white/10 rounded-xl flex items-center justify-between text-xs text-white transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Download className="w-4 h-4 text-[#00D632]" />
                    Export Gate HTML
                  </span>
                  <span className="text-[10px] text-gray-500">.html</span>
                </a>

                <a
                  href="/api/admin/export"
                  download="zyre-database-backup.json"
                  className="p-3.5 bg-[#161821] hover:bg-[#1e2230] border border-white/10 rounded-xl flex items-center justify-between text-xs text-white transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Download className="w-4 h-4 text-blue-400" />
                    Download DB Backup
                  </span>
                  <span className="text-[10px] text-gray-500">.json</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* ==================================================== */}
      {/* MODAL: GENERATE NEW LICENSE KEYS */}
      {/* ==================================================== */}
      {isGenerateOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#0e1015] border border-white/10 rounded-3xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-white/5 mb-4">
              <div className="flex items-center gap-2">
                <Key className="w-5 h-5 text-[#00D632]" />
                <h3 className="font-bold text-base text-white">Generate Real Customer Keys</h3>
              </div>
              <button
                onClick={() => {
                  setIsGenerateOpen(false);
                  setGeneratedResult(null);
                }}
                className="text-gray-400 hover:text-white text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            {generatedResult ? (
              <div className="space-y-4">
                <div className="p-4 bg-green-950/30 border border-green-500/30 rounded-2xl text-xs text-green-300">
                  Successfully generated {generatedResult.length} customer key(s)!
                </div>

                <div className="max-h-60 overflow-y-auto space-y-2 font-mono text-xs">
                  {generatedResult.map((k) => (
                    <div key={k.id} className="flex items-center justify-between p-3 bg-black/50 border border-white/5 rounded-xl">
                      <span className="text-[#00D632] font-bold">{k.key}</span>
                      <button
                        onClick={() => handleCopy(k.key, k.id)}
                        className="text-gray-400 hover:text-white flex items-center gap-1 text-[11px]"
                      >
                        {copiedKey === k.id ? <Check className="w-3.5 h-3.5 text-[#00D632]" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>Copy</span>
                      </button>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setGeneratedResult(null)}
                  className="w-full py-3 bg-[#161821] hover:bg-[#202330] rounded-xl text-xs font-bold text-white cursor-pointer"
                >
                  Generate More Keys
                </button>
              </div>
            ) : (
              <form onSubmit={handleGenerateSubmit} className="space-y-4 text-xs">
                {/* Duration Presets */}
                <div>
                  <label className="block text-gray-400 font-semibold mb-2">DURATION PRESET</label>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { label: '1 Day', val: '1', unit: 'days' },
                      { label: '7 Days', val: '7', unit: 'days' },
                      { label: '30 Days (1 Mo)', val: '30', unit: 'months' },
                      { label: '90 Days (3 Mo)', val: '90', unit: 'months' },
                      { label: '180 Days (6 Mo)', val: '180', unit: 'months' },
                      { label: '1 Year (365d)', val: '365', unit: 'years' },
                      { label: '2 Years', val: '730', unit: 'years' },
                      { label: 'Lifetime VIP', val: '3650', unit: 'lifetime' }
                    ].map(p => (
                      <button
                        key={p.val}
                        type="button"
                        onClick={() => {
                          setGenDurationPreset(p.val);
                          setGenCustomDays(parseInt(p.val, 10));
                          setGenUnit(p.unit as any);
                        }}
                        className={`p-2.5 rounded-xl text-center font-bold text-xs border transition-all cursor-pointer ${
                          genDurationPreset === p.val
                            ? 'bg-[#00D632] text-black border-[#00D632] shadow-[0_0_12px_rgba(0,214,50,0.3)]'
                            : 'bg-[#14161f] border-white/5 text-gray-300 hover:border-white/20'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Batch Count */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-gray-400 font-semibold mb-1.5">QUANTITY</label>
                    <input
                      type="number"
                      min={1}
                      max={50}
                      value={genCount}
                      onChange={(e) => setGenCount(parseInt(e.target.value, 10) || 1)}
                      className="w-full bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-xl px-3 py-2.5 text-white font-mono text-xs outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-400 font-semibold mb-1.5">BUYER NOTES</label>
                    <input
                      type="text"
                      value={genNotes}
                      onChange={(e) => setGenNotes(e.target.value)}
                      placeholder="e.g. Buyer John / Order #104"
                      className="w-full bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-xl px-3 py-2.5 text-white text-xs outline-none"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#00D632] hover:bg-[#00c02d] text-black font-bold rounded-xl text-xs uppercase tracking-wider transition-all shadow-[0_4px_16px_rgba(0,214,50,0.3)] cursor-pointer"
                >
                  Generate {genCount} Real License Key{genCount > 1 ? 's' : ''}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* MODAL: EXTEND LICENSE DURATION */}
      {/* ==================================================== */}
      {extendModalKey && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0e1015] border border-white/10 rounded-3xl p-6 shadow-2xl relative text-xs">
            <h3 className="font-bold text-base text-white mb-2">Extend License Duration</h3>
            <p className="text-gray-400 mb-4 font-mono">
              Key: <span className="text-[#00D632]">{extendModalKey.key}</span>
            </p>

            <div className="space-y-3 mb-6">
              <label className="block text-gray-400 font-semibold">ADD DAYS</label>
              <div className="grid grid-cols-4 gap-2">
                {[7, 30, 90, 365].map(d => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setExtendDays(d)}
                    className={`p-2 rounded-xl font-bold ${
                      extendDays === d ? 'bg-[#00D632] text-black' : 'bg-[#161821] text-gray-300'
                    }`}
                  >
                    +{d}d
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setExtendModalKey(null)}
                className="flex-1 py-3 bg-[#161821] hover:bg-[#202330] rounded-xl text-white font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleExtendDuration}
                className="flex-1 py-3 bg-[#00D632] hover:bg-[#00c02d] rounded-xl text-black font-bold cursor-pointer"
              >
                Confirm (+{extendDays}d)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
