import React, { useState, useEffect } from 'react';
import { Shield, Key, Cpu, Copy, Check, AlertTriangle, Lock, Monitor } from 'lucide-react';
import { DeviceHardwareInfo } from '../utils/hwid';

interface KeyGateProps {
  hardwareInfo: DeviceHardwareInfo | null;
  onActivateSuccess: (session: {
    token: string;
    key: string;
    expiresAt: string | null;
    boundHwid: string;
    notes?: string;
  }) => void;
  initialError?: string | null;
}

export const KeyGate: React.FC<KeyGateProps> = ({
  hardwareInfo,
  onActivateSuccess,
  initialError
}) => {
  const [licenseKey, setLicenseKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(initialError || null);
  const [copiedHwid, setCopiedHwid] = useState(false);

  useEffect(() => {
    if (initialError) {
      setError(initialError);
    }
  }, [initialError]);

  const handleCopyHwid = () => {
    if (hardwareInfo?.hwid) {
      navigator.clipboard.writeText(hardwareInfo.hwid);
      setCopiedHwid(true);
      setTimeout(() => setCopiedHwid(false), 2000);
    }
  };

  const handleFormatKey = (val: string) => {
    const clean = val.toUpperCase().replace(/[^A-Z0-9-]/g, '');
    setLicenseKey(clean);
    if (error) setError(null);
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        handleFormatKey(text.trim());
      }
    } catch {}
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!licenseKey.trim()) {
      setError('Please enter your Zyre license key');
      return;
    }
    if (!hardwareInfo?.hwid) {
      setError('Generating hardware fingerprint... please wait a moment.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/auth/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: licenseKey.trim(),
          hwid: hardwareInfo.hwid,
          deviceInfo: {
            os: hardwareInfo.os,
            browser: hardwareInfo.browser,
            screen: hardwareInfo.screenRes,
            cores: hardwareInfo.cores,
            gpu: hardwareInfo.gpu,
            userAgent: hardwareInfo.userAgent,
            timezone: hardwareInfo.timezone,
            language: hardwareInfo.language
          }
        })
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setError(data.error || 'Activation failed. Please verify your license key.');
        setLoading(false);
        return;
      }

      // Save token and key
      localStorage.setItem('zyre_session_token', data.token);
      localStorage.setItem('zyre_license_key', data.key);
      localStorage.setItem('zyre_expires_at', data.expiresAt || '');

      onActivateSuccess({
        token: data.token,
        key: data.key,
        expiresAt: data.expiresAt,
        boundHwid: data.hwid,
        notes: data.notes
      });
    } catch (err: any) {
      setError('Failed to connect to authentication server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-4 relative overflow-hidden select-none">
      {/* Background ambient neon glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#00D632]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-72 h-40 bg-[#00D632]/5 rounded-full blur-2xl pointer-events-none" />

      {/* Main Verification Card */}
      <div className="w-full max-w-md bg-[#0d0e12] border border-[#222] rounded-3xl p-6 sm:p-8 shadow-2xl relative z-10 backdrop-blur-xl">
        {/* Brand Header */}
        <div className="flex flex-col items-center text-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-[#00D632]/10 border border-[#00D632]/30 flex items-center justify-center mb-4 shadow-[0_0_25px_rgba(0,214,50,0.2)]">
            <Shield className="w-8 h-8 text-[#00D632]" />
          </div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-2xl font-black tracking-tight text-white">ZYRE</span>
            <span className="px-2 py-0.5 text-[10px] font-bold bg-[#00D632]/20 text-[#00D632] border border-[#00D632]/40 rounded-full uppercase tracking-wider">
              HWID LOCKED
            </span>
          </div>
          <p className="text-xs text-gray-400">
            Hardware-bound licensing terminal. Locked to one device.
          </p>
        </div>

        {/* Device HWID Card */}
        <div className="bg-[#14161d] border border-white/5 rounded-2xl p-4 mb-6">
          <div className="flex items-center justify-between text-xs text-gray-400 mb-2">
            <span className="flex items-center gap-1.5 font-medium">
              <Cpu className="w-3.5 h-3.5 text-[#00D632]" />
              THIS DEVICE HARDWARE ID
            </span>
            <button
              onClick={handleCopyHwid}
              type="button"
              className="text-[#00D632] hover:text-[#00D632]/80 flex items-center gap-1 transition-colors cursor-pointer"
            >
              {copiedHwid ? (
                <>
                  <Check className="w-3 h-3" />
                  <span className="text-[11px]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-[11px]">Copy HWID</span>
                </>
              )}
            </button>
          </div>

          <div className="font-mono text-sm tracking-wider text-[#00D632] bg-black/40 border border-[#00D632]/20 rounded-xl px-3 py-2 text-center select-all break-all">
            {hardwareInfo?.hwid || 'INITIALIZING HARDWARE ID...'}
          </div>

          {hardwareInfo && (
            <div className="mt-2.5 flex items-center justify-between text-[11px] text-gray-500 border-t border-white/5 pt-2">
              <span className="flex items-center gap-1">
                <Monitor className="w-3 h-3 text-gray-400" />
                {hardwareInfo.os} · {hardwareInfo.browser}
              </span>
              <span>{hardwareInfo.screenRes.split('@')[0]}</span>
            </div>
          )}
        </div>

        {/* Error / Alert Message */}
        {error && (
          <div className="mb-5 bg-red-950/40 border border-red-500/40 rounded-2xl p-3.5 text-xs text-red-200 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1 leading-relaxed">{error}</div>
          </div>
        )}

        {/* License Key Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1.5 text-xs font-medium text-gray-300">
              <label htmlFor="licenseKey" className="flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-[#00D632]" />
                ENTER LICENSE KEY
              </label>
              <button
                type="button"
                onClick={handlePaste}
                className="text-xs text-gray-400 hover:text-white transition-colors cursor-pointer"
              >
                Paste
              </button>
            </div>
            <div className="relative">
              <input
                id="licenseKey"
                type="text"
                value={licenseKey}
                onChange={(e) => handleFormatKey(e.target.value)}
                placeholder="ZYRE-XXXX-XXXX-XXXX"
                maxLength={32}
                autoFocus
                autoComplete="off"
                spellCheck={false}
                className="w-full bg-[#161821] border border-white/10 focus:border-[#00D632] rounded-2xl py-3.5 px-4 text-center font-mono text-base tracking-widest text-white placeholder-gray-600 outline-none transition-all shadow-inner focus:shadow-[0_0_20px_rgba(0,214,50,0.15)]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#00D632] hover:bg-[#00c02d] active:scale-[0.98] disabled:opacity-50 text-black font-bold py-4 rounded-2xl text-sm tracking-wide transition-all shadow-[0_4px_20px_rgba(0,214,50,0.3)] flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>AUTHENTICATING & LOCKING...</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>ACTIVATE & UNLOCK ZYRE</span>
              </>
            )}
          </button>
        </form>

        {/* Security Notice */}
        <div className="mt-6 text-[11px] text-center text-gray-500 leading-relaxed border-t border-white/5 pt-4">
          Anti-leak protected: Each license key is cryptographically bound to one physical device hardware signature.
        </div>
      </div>
    </div>
  );
};
